<?php
session_start();
if(!isset($_SESSION['guestID']))
	header("location:HotelGosselin.php");
$DBConnect = @mysqli_connect("localhost", "klince", "mvcc")
	Or die("<p>Unable to connect to the database server.</p>"
	."<p>Error code ".mysqli_connect_errno()
	.": ".mysqli_connect_error())."</p>";
$DBName = "hotel_gosselin";
@mysqli_select_db($DBConnect, $DBName)
		Or die("<p>Unable to select the database.</p>"
		."<p>Error code ".mysqli_errno($DBConnect)
		.": ".mysqli_error($DBConnect))."</p>";
$CustomerName = "";
if(isset($_COOKIE['customerName']))
	$CustomerName = $_COOKIE['customerName'];
mysqli_close($DBConnect);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Hotel Gosselin</title>
<link rel = "stylesheet" href="php_styles.css" type = "text/css" />
</head>
<body>
<h1>Hotel Gosselin</h1>
<h2>Front Desk</h2>
<table frame="border" rules="cols">
<colgroup width="50%"/>
<colgroup width="50%"/>
<tr><td align="left">
<p><strong>Guest Name: </strong><?= $CustomerName ?></p>
<p><strong>Guest #: </strong>
<?= $_SESSION['guestID'] ?></p>
</td>
<td align="center">
<p><a href='<?php echo "UpdateContactInfo.php?"
. SID ?>'>Update Contact Info</a></p>
</td></tr>
<tr><td><strong>Reservations</strong></td>
<td align="center">
<p><a href='<?php echo "Reserve.php?"
. SID ?>'>Create New Reservation</a><br />
<a href='<?php echo "ViewReservations.php?"
. SID ?>'>View Existing Reservations</a><br />
<a href='<?php echo "ChangeReservation.php?"
. SID ?>'>Change Reservation</a><br />
<a href='<?php echo "CancelReservation.php?"
. SID ?>'>Cancel Reservation</a><br />
</p>
</td>
</tr>

</table>
<p><a href="HotelGosselin.php">Log Out</a></p>
</body>
</html>