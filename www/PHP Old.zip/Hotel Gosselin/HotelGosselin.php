<?php
session_start();
$_SESSION = array();
session_destroy();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Hotel Gosselin</title>
<link rel = "stylesheet" href="php_styles.css" type = "text/css" />
<meta http-equiv="content-type"
content="text/html; charset = iso-8859-1"/>
</head>
<body>
<h1>Hotel Gosselin</h1>
<h2>New Guest Registration</h2>
<form action="RegisterGuest.php" method="get">
<table frame="border" rules="cols">
<colgroup width="50%"/>
<colgroup width="50%"/>
<tr><td align="left" valign="top">
<p>E-Mail Address</p>
<p><input type="text" name="email" size="36" /></p>
<p>Confirm E-Mail Address</p>
<p><input type="text" name="email_confirm" size="36" /></p>
</td>
<td align="left" valign="top">
<p>Password(5-10 Characters)</p>
<p><input type="password" name="password" size="36"/></p>
<p>Confirm Password</p>
<p><input type="password" name="password_confirm" size="36"/></p>
</td>
</tr>
<tr><td align="center" colspan="2"><input type="submit" value="		Register	"/></td></tr>
</table>
</form>
<h2>Returning Guests</h2>
<?php if(isset($_COOKIE['customerName'])) echo "<p>Welcome Back {$_COOKIE['customerName']}!";?>
<form method="get" action="ValidateUser.php" >
<table frame="border" rules="cols">
<colgroup width="50%"/>
<colgroup width="50%"/>
<tr><td align="left" valign="top">
<p>E-Mail Address</p>
<p><input type="email" size="36" /> </p>
</td>
<td align="left" valign="top" >
<p>Password</p>
<p><input type="password" name="password" size="36" /></p>
</td></tr>
<tr><td align="center" colspan="2"><input type="submit" value="		Log In	"/></td></tr>
</table>
</form>
</body>
</html>