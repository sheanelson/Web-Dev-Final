<?php
session_start();
if (!isset($_SESSION['guestID']))
	header("location:HotelGosselin.php");
$GuestID = $_SESSION['guestID'];
$DBConnect = @mysqli_conect("localhost", "klince", "mvcc")
or die ("<p>Unable to connect to the database server.</p>"
."<p>Error code" .mysqli_connect_errno()
.":". mysqli_connect_error()). "</p>";
$DBName = "hotel_gosselin";
@mysqli_select_db($DBConnect, $DBName)
or die("<p>Unable to select the database.</p>"
."<p>Error code" .mysqli_errno($DBConnect)
.":" .mysqli_errors($DBConnect)). "</p>";
$TableNames = "guests";
$SQLstring = "SELECT * FROM $TableName WHERE guestID='{$_SESSION['guestID']}'";
$QueryResult = @mysqli_query($DBConnect, $SQLstring)
or die("<p>Unable to execute the query.</p>"
."<p>Error code" .mysqli_errno($DBConnect)
.":" .mysqli_error($DBConnect)). "</p>";
if (mysqli_num_rows($QueryResult) > 0){
	$Row = mysqli_fetch_row($QueryResult);
	$First = stripslashes($Row[3]);
	$Last = stripslashes($Row[4]);
	mysqli_free_result($QueryResult);
}
else
	exit("<p>No result returned! Invalid guest ID. </p>");
mysqli_close($DBConnect);
?>
<script type="text/javascript">
<!--HIDE FROM INCOMPATIBLE BROWSERS
function UpdatePrice(){
	var roomRate = 100;
	if(document.forms[0].room_type[1].checked == true)
		roomRate = 150;
	else if (document.forms.room_type[2].checked == true)
		roomRate = 200;
	roomRate *=document.forms[0].number_nights.value;
	roomRate += (document.forms[0].number_guests.value*25);
	if (document.forms[0].discount.value != "None")
		roomRate = roomRate / 1.1;
	document.forms[0].price.value = "$" + roomRate.toFixed(2);
}
//STOP HIDING FROM INCOMPATIBLE BROWSERS -->
</script>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0Strict//EN"
	"http://www.w3.org/TR/xhtml/DTD/xhtml1-strict.dtd">
<html>
<head>
<title>Hotel Gosselin </title>
<link rel="stylesheet" href="php_styles.css" type="text/css" />
</head>
<body onLoad="UpdatePrice();">
<h1>Hotel Gosselin</h1>
<h2>New Reservation</h2>
<p><strong>Guest ID</strong>: <?=$GuestID ?><br />
<strong>Guest Name</strong>: <?="$First $Last" ?>
</p>
<form action= "ReserveRoom.php" method="post" >
<p>Check In Month <input type= "text" name="checkin_month" /><br />
Check In Day <input type= "text" name= "checkin_day" /><br />
Check In Day <input type= "text" name= "checkin_year" /></p>
<p><input type="radio" name="room_type" value= "standard" checked= "checked" onChange= "return UpdatePrice();" /> Standard Room&nbsp;
<input type= "radio" name="room_type" value="junior" onchange="return UpdatePrice();" />Junior Suite &nbsp;
<input type= "radio" name="room_type" value="suite" onchange="return UpdatePrice();" />Full Suite &nbsp;
<p>No. of Nights &nbsp; <input name="number_nights" value="1" size="10" onChange="return UpdatePrice();" /></p>
<p>No. of People &nbsp; <input name="number_guests" value="1" size="10" onChange="return UpdatePrice();" /> ($25 per guest)</p>
<p>Discount <select name="discount" onChange="return UpdatePrice();">
<option value="None">None</option>
<option value="Corporate">Corporate</option>
<option value="AAA">AAA</option>
<option value="AARP">AARP</option>
</select> (10% off) </p>
<p>Price: <input type="text" name="price" value="0" /></p>
<p><input type="submit" value="Submit Reservation" />
<input type="reset" /><input type="hidden" name="PHPSESSID"
value='<?php echo session_id() ?>; /></p>
</form>
<p><a href='<?echo "FrontDesk.php?"
.SID ?>'>Front Desk</a></p>
</body>
</html>