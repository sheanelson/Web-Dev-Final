<?php
session_start();
if(!isset($_SESSION['guestID']))
	header("location:HotelGosselin.php");
if(empty($_GET['first_name']) || empty($_GET['last_name']) || empty($_GET['phone']) || empty($_GET['address']) || empty($_GET['city']) || empty($_GET['state']) || empty($_GET['zip']))
	exit("<p>You must enter values in all fields of the Contact Information form! Click your browser's Back buton to return to the previous page.</p>");
$First = addslashes($_GET['first_name']);
$Last = addslashes($_GET['last_name']);
$Phone = addslashes($_GET['phone']);
$Address = addslashes($_GET['address']);
$City = addslashes($_GET['city']);
$State = addslashes($_GET['state']);
$Zip = addslashes($_GET['zip']);
setcookie("customerName", $First . " " . $Last, 
time() + 60*60*24*7);
$DBConnect = @mysqli_connect("localhost", "klince", "mvcc")
	Or die("<p>Unable to connect to the database server.</p>"
	."<p>Error code " .mysqli_connect_errno()
	.":".mysqli_connect_error()). "</p>";
$DBName = "hotel_gosselin";
@mysqli_select_db($DBCConnect, $DBName)
	Or die("<p>Unable to select the database.</p>"
	."<p>Error code " .mysqli_connect_errno($DBConnect)
	.":".mysqli_connect_error($DBConnect)). "</p>";
$TableName = "guests";
$SQLstring = "UPDATE $TableName SET first='$First', last='$Last', phone='$Phone', address='$Address', city='$City', state='$State', zip='$Zip' WHERE guestID='{$_SESSION['guestID']}'";
$QueryResult = @mysqli_query($DBConnect, $SQLstring)
	Or die("<p>Unable to execute the query.</p>"
	."<p>Error code " .mysqli_connect_errno($DBConnect)
	.":".mysqli_connect_error($DBConnect)). "</p>";
mysqli_close($DBConnect);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<xhtml xmlns="http://www/w3/org/19999/xhtml">
<head>
<title>Hotel Gosselin</title>
<link rel="stylesheet" href="php_styles.css" type="text/css" />
<meta http-equiv="content-type"
content="text/html; charset=iso-8859-1" />
</head>
<body>
<h1>Hotel Gosselin</h1>
<h2>Contact Info Updated</h2>
<p>You contact information was successfully updated.</p>
<p><a href='<?php echo "FrontDesk.php?" . SID ?>'>Front Desk</a></p>
</body>
</html>
