<?php
session_start();
if (!isset($_SESSION['guestID']))
	header("location:HotelGosselin.php");
$DBConnect = @mysqli_conect("localhost", "klince", "mvcc")
or die ("<p>Unable to connect to the database server.</p>"
."<p>Error code" .mysqli_connect_errno()
.":". mysqli_connect_error()). "</p>";
$DBName = "hotel_gosselin";
@mysqli_select_db($DBConnect, $DBName)
or die("<p>Unable to select the database.</p>"
."<p>Error code" .mysqli_errno($DBConnect)
.":" .mysqli_errors($DBConnect)). "</p>";
$TableNames = "guests";
$SQLstring = "SELECT * FROM $TableName WHERE guestID='{$_SESSION['guestID']}'";
$QueryResult = @mysqli_query($DBConnect, $SQLstring)
or die("<p>Unable to execute the query.</p>"
."<p>Error code" .mysqli_errno($DBConnect)
.":" .mysqli_error($DBConnect)). "</p>";
if (mysqli_num_rows($QueryResult) > 0){
	$Row = mysqli_fetch_row($QueryResult);
	$First = stripslashes($Row[3]);
	$Last = stripslashes($Row[4]);
	$Phone = stripslashes($Row[5]);
	$Address = stripslashes($Row[6]);
	$City = stripslashes($Row[7]);
	$State = stripslashes($Row[8]);
	$Zip = stripslashes($Row[9]);
	mysqli_free_result($QueryResult);
}
else {
	$First = "";
	$Last = "";
	$Phone = "";
	$Address = "";
	$City = "";
	$State = "";
	$Zip = "";
}
mysqli_close($DBConnect);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Hotel Gosselin</title>
<link rel="stylesheet" href= "php_styles.css" type="text/css" />
<meta http-equiv="Content-Type"
content="text/html; charset=iso-8859-1" />
</head>
<body>
<h1>Hotel Gosselin</h1>
<h2>Contact Information</h2>
<form action="ContactUpdate.php" method="get">
<table frame="border" rules="cols">
<colgroup width="50%" />
<colgroup height="50%" />
<tr><td align="right" valign="top">
<p>First Name <input type="text" name="first_name"
value="<?= $First ?>" size="36" /></p>
<p>Last Name <input type="text" name="last_name"
value="<?= $Last ?>" size="36" /></p>
<p>Phone <input type="text" name="phone"
value="<?= $Phone ?>" size="36" /></p></td>
<td align="right" valign="top">
<p>Address <input type="text" name="address"
value="<? $Address ?>" size="40" /></p>
<p>City <input type="text" name="city" value="<?=$City ?>"
size="10" />
State <input type="text" name="state" value="<?= $State ?>"
size="2" maxlength="2" />
Zip <input type="text" name="zip" value="<?= $Zip ?>" size="10"
maxlength="10" /></p>
</td></tr>
</table>
<p><input type="hidden" name="PHPSESSID"
value='<?php echo session_id() ?>' />
<input type="submit" value="Submit" /></p>
</form>
</body>
</html>