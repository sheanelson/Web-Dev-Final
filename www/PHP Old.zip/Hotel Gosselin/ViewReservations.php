<?php
session_start();
if(!isset($_SESSION['guestID']))
	header("location:HotelGosselin.php");
$GuestID = $_SESSION['guestID'];
$DBConnect = @mysqli_connect("localhost", "klince", "mvcc")
	Or die("<p>Unable to connect to the database server.</p>"
	."<p>Error code ".mysqli_connect_errno()
	.": ".mysqli_connect_error())."</p>";
$DBName = "hotel_gosselin";
@mysqli_select_db($DBConnect, $DBName)
		Or die("<p>Unable to select the database.</p>"
		."<p>Error code ".mysqli_errno($DBConnect)
		.": ".mysqli_error($DBConnect))."</p>";
$TableName = "guests";
$SQLstring = "SELECT * FROM $TableName WHERE guestID='{$_SESSION['guestID']}'";
$QueryResult = @mysqli_query($DBConnect, $SQLstring)
		Or die("<p>Unable to execute the query.</p>"
		."<p>Error code ".mysqli_errno($DBConnect)
		.": ".mysqli_error($DBConnect))."</p>";
if(mysqli_num_rows($QueryResult) > 0){
	$Row = mysqli_fetch_row($QueryResult);
	$First = stripslashes($Row[3]);
	$Last = stripslashes($Row[4]);
}
else
	exit("<p>No result returned! Invalid guest ID!.</p>");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Hotel Gosselin</title>
<link rel = "stylesheet" href="php_styles.css" type = "text/css" />
<meta http-equiv="content-type"
content="text/html; charset = iso-8859-1"/>
</head>
<body>
<h1>Hotel Gosselin</h1>
<h2>Current Reservation</h2>
<p><strong>Guest ID</strong>: <?= $GuestID ?><br />
<strong>Guest Name</strong>: <?= "$First $Last" ?>
</p>
<table frame="border" rules="cols">
<tr><th>Reservation ID</th><th> Checking In </th><th> Room Type </th><th> Nights </th><th>Guests </th><th> Discount </th><th> Price </th></tr>
<?php
$TableName = "reservations";
$SQLstring = "SELECT * FROM $TableName WHERE guestID='{$_SESSION['guestID']}'";
$QueryResult = @mysqli_query($DBConnect, $SQLstring)
		Or die("<p>Unable to execute the query.</p>"
		."<p>Error code ".mysqli_errno($DBConnect)
		.": ".mysqli_error($DBConnect))."</p>";
if(mysqli_num_rows($QueryResult) > 0){
	$Row = mysqli_fetch_row($QueryResult);
	echo"<p>";
	do{
		echo"<tr><td>{$Row[0]}</td><td>{$Row[2]}{$Row[3]}{$Row[4]}</td><td>{$Row[5]}</td><td>{$Row[6]}</td><td>{$Row[7]}</td><td>{$Row[8]}</td><td>{$Row[9]}</td></tr>"	;
		$Row = mysqli_fetch_row($QueryResult);
	}while($Row);
	mysqli_free_result($QueryResult);
}
mysqli_close($DBConnect);
?>
<p><input type="hidden" name="PHPSESSID"
value='<?php echo_session_id() ?>' /></p>
</table>
<p><a href='<?php echo "FrontDesk.php?"
. SID ?>'>Front Desk</a></p>
</body>
</html>