<?php
session_start();
$GuestEmail = $_GET['email'];
$GuestPassword = $_GET['password'];
if(empty($GuestEmail) || empty($GuestPassword))
	exit("<p>You must enter your email address and password!
Click your browsers back button to return to the
previous page.</p>");
$DBConnect = @mysqli_connect("localhost", "klince", "mvcc")
	Or die("<p>Unable to connect to the database server.</p>"
	."<p>Error code ".mysqli_connect_errno()
	.": ".mysqli_connect_error())."</p>";
$DBName = "hotel_gosselin";
@mysqli_select_db($DBConnect, $DBName)
		Or die("<p>Unable to select the database.</p>"
		."<p>Error code ".mysqli_errno($DBConnect)
		.": ".mysqli_error($DBConnect))."</p>";
$TableName = "guests";
$SQLstring = "SELECT * FROM $TableName WHERE email='$GuestEmail'";
$QueryResult = @mysqli_query($DBConnect, $SQLstring)
		Or die("<p>Unable to execute the query.</p>"
		."<p>Error code ".mysqli_errno($DBConnect)
		.": ".mysqli_error($DBConnect))."</p>";
if(mysqli_num_rows($QueryResult) == 0)
	die("<p>You must enter a registered email address!
Click your browsers back button to return to the
Registration form.</p>");
$Row = mysqli_fetch_row($QueryResult);
if($GuestPassword != $Row[2])
	exit("<p>You did not enter a valid password! Click your browsers back button to return to the previous page.</p>");
else
	$_SESSION['guestID'] = $Row[0];
mysqli_close($DBConnect);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Hotel Gosselin</title>
<link rel = "stylesheet" href="php_styles.css" type = "text/css" />
<meta http-equiv="content-type"
content="text/html; charset = iso-8859-1"/>
</head>
<body>
<h1>Hotel Gosselin</h1>
<h2>Reservation Updated</h2>
<p><a href='<?php echo "FrontDesk.php?". SID ?>'>Front Desk</a></p>
</body>
</html>