<?php
session_start();
if(!isset($_SESSION['guestID']))
	header("location:HotelGosselin.php");
$GuestID = $_SESSION['guestID'];
if(empty($_SESSION['reservationID']))
	exit("<p>You must enter a reservation ID in the Cance Reservation form! Click your browsers back button to return to the previous page.</p>");
$ReservationID = $_SESSION['reservationID'];
if(empty($_POST['checkin_month']) || empty($_POST['checkin_day'])
	|| empty($_POST['checkin_year']) || empty($_POST['room_type'])
	|| empty($_POST['number_nights'])
	|| empty($_POST['number_guests'])
	|| empty($_POST['discount'])
	|| empty($_POST['price']))
	exit("<p>You must enter values in all fields of the change registration form! Click your browsers back button to return to the previous page.</p>");
$GuestID = $_SESSION['guestID'];
$Month = $_POST['checkin_month'];
$Day = $_POST['checkin_day'];
$Year = $_POST['checkin_year'];
$RoomType = $_POST['room_type'];
$NumNights = $_POST['number_nights'];
$NumGuests = $_POST['number_guests'];
$Discount = $_POST['discount'];
$Price = $_POST['price'];
$DBConnect = @mysqli_connect("localhost", "klince", "mvcc")
	Or die("<p>Unable to connect to the database server.</p>"
	."<p>Error code ".mysqli_connect_errno()
	.": ".mysqli_connect_error())."</p>";
$DBConnect = @mysqli_connect("localhost", "dongosselin", "rosebud")
	Or die("<p>Unable to connect to the database server.</p>"
	."<p>Error code ".mysqli_connect_errno()
	.": ".mysqli_connect_error())."</p>";
$DBName = "hotel_gosselin";
@mysqli_select_db($DBConnect, $DBName)
		Or die("<p>Unable to select the database.</p>"
		."<p>Error code ".mysqli_errno($DBConnect)
		.": ".mysqli_error($DBConnect))."</p>";
		
$TableName = "reservations";
$SQLstring = "UPDATE $TableName SET checkin_month = '$Month', checkin_day = '$Day', checkin_year = '$Year', room_type = '$RoomType', number_nights = '$NumNights', number_guests = '$NumGuests', discount = '$Discount', price = '$Price' WHERE reservationdID = '$ReservationID'";
$QueryResult = @mysqli_query($DBConnect, $SQLstring)
		Or die("<p>Unable to execute the query.</p>"
		."<p>Error code ".mysqli_errno($DBConnect)
		.": ".mysqli_error($DBConnect))."</p>";
mysqli_close($DBConnect);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Hotel Gosselin</title>
<link rel = "stylesheet" href="php_styles.css" type = "text/css" />
<meta http-equiv="content-type"
content="text/html; charset = iso-8859-1"/>
</head>
<body>
<h1>Hotel Gosselin</h1>
<h2>Reservation Updated</h2>
<p><a href='<?php echo "FrontDesk.php?"
. SID ?>'>Front Desk</a></p>
</body>
</html>