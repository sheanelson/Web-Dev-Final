<?php
session_start();
if(empty($_GET['email']) || empty($_GET['email_confirm'])
	|| empty($_GET['password']) || empty($_GET['password_confirm']))
	exit("<p>You must enter values in all fields of the New Guest Registration form! Click your browsers back button to return to the previous page.</p>");
else if(!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-)+)*(\.[a-z]{2,3})$i", $_GET['email']))
	exit("<p>You did not enter a valid e-mail address! Click your browsers back button to return to the previous page.</p>");
else if($_GET['email'] != $_GET['email_confirm'])
	exit("<p>You did not enter the same e-mail address! Click your browsers back button to return to the previous page.</p>");
else if($_GET['password'] != $_GET['password_confirm'])
	exit("<p>You did not enter the same password! Click your browsers back button to return to the previous page.</p>");
else if(strlen($_GET['password']) <5 || strlen($_GET['password']) >10)
	exit("<p>You must enter a password between 5 and 10 Characters! Click your browsers back button to return to the previous page.</p>");
$DBConnect = @mysqli_connect("localhost", "klince", "mvcc")
	Or die("<p>Unable to connect to the database server.</p>"
	."<p>Error code ".mysqli_connect_errno()
	.": ".mysqli_connect_error())."</p>";
$DBName = "hotel_gosselin";
if(!@mysqli_select_db($DBConnect, $DBName)){
	$SQLstring = "CREATE DATABASE $DBName";
	$QueryResult = @mysqli_query($DBConnect, $SQLstring)
		Or die("<p>Unable to execute the query.</p>"
		."<p>Error code ".mysqli_errno($DBConnect)
		.": ".mysqli_error($DBConnect))."</p>";
	echo "<p>Succesfully created the database.</p>";
	mysqli_select_db($DBConnect, $DBName);
}
$TableName = "guests";
$SQLstring = "SELECT * FROM $TableName";
$QueryResult = @mysqli_query($DBConnect, $SQLstring);
if(!$QueryResult){
	$SQLstring = "CREATE TABLE $TableName (guestID SMALLINT NOT NULL
		AUTO_INCREMENT PRIMARY KEY, email VARCHAR(40),
		password VARCHAR(10), first VARCHAR(40), last VARCHAR(40),
		phone VARCHAR(40), address VARCHAR(40), city VARCHAR(40),
		state VARCHAR(2), zip VARCHAR(10))";
	$QueryResult = @mysqli_query($DBConnect, $SQLstring)
		Or die("<p>Unable to execute the query.</p>"
		."<p>Error code ".mysqli_errno($DBConnect)
		.": ".mysqli_error($DBConnect))."</p>";
	echo "<p>Succesfully created $TableName table.</p>";
}
$Email = addslashes($_GET['email']);
$Password = addslashes($_GET['password']);
$SQLstring = "SELECT * FROM $TableName";
$QueryResult = @mysqli_query($DBConnect, $SQLstring);
if(mysqli_num_rows($QueryResult) >0){
	$Row = mysqli_fetch_row($QueryResult);
	do{
		if(in_array($Email, $Row))
		exit("<p>The e-mail address you entered is already 
		registered! Click your browsers back button to 
		return to the previous page.</p>");
		$Row = mysqli_fetch_row($QueryResult);
	}while($Row);
	mysqli_free_result($QueryResult);
}
$SQLstring = "INSERT INTO $TableName VALUES(NULL, '$Email',
'$Password', NULL, NULL, NULL, NULL, NULL, NULL, NULL)";
$QueryResult = @mysqli_query($DBConnect, $SQLstring)
		Or die("<p>Unable to execute the query.</p>"
		."<p>Error code ".mysqli_errno($DBConnect)
		.": ".mysqli_error($DBConnect))."</p>";
$_SESSION['guestID'] = mysqli_insert_id($DBConnect);
mysqli_close($DBConnect);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Hotel Gosselin</title>
<link rel = "stylesheet" href="php_styles.css" type = "text/css" />
<meta http-equiv="content-type"
content="text/html; charset = iso-8859-1"/>
</head>
<body>
<h1>Hotel Gosselin</h1>
<h2>New Guest Registration</h2>
<p>Your new guest ID id <strong>
<?php $_SESSION['guestID'] ?></strong>.</p>
<p><a href=href='<?php echo "UpdateContactInfo.php?"
. SID ?>'>Enter Contact Information</a></p>
</body>
</html>