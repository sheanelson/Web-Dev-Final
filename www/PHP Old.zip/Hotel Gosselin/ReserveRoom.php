<?php
session_start();
if(empty($_POST['checkin_month']) || empty($_POST['checkin_day'])
	|| empty($_POST['checkin_year']) || empty($_POST['room_type'])
	|| empty($_POST['number_nights'])
	|| empty($_POST['number_guests'])
	|| empty($_POST['discount'])
	|| empty($_POST['price']))
	exit("<p>You must enter values in all fields of the change registration form! Click your browsers back button to return to the previous page.</p>");
	$GuestID = $_SESSION['guestID'];
$Month = $_POST['checkin_month'];
$Day = $_POST['checkin_day'];
$Year = $_POST['checkin_year'];
$RoomType = $_POST['room_type'];
$NumNights = $_POST['number_nights'];
$NumGuests = $_POST['number_guests'];
$Discount = $_POST['discount'];
$Price = $_POST['price'];
$DBConnect = @mysqli_connect("localhost", "klince", "mvcc")
	Or die("<p>Unable to connect to the database server.</p>"
	."<p>Error code ".mysqli_connect_errno()
	.": ".mysqli_connect_error())."</p>";
if(!isset($_SESSION['guestID']))
	header("location:HotelGosselin.php");
$DBConnect = @mysqli_connect("localhost", "dongosselin", "rosebud")
	Or die("<p>Unable to connect to the database server.</p>"
	."<p>Error code ".mysqli_connect_errno()
	.": ".mysqli_connect_error())."</p>";
$DBName = "hotel_gosselin";
@mysqli_select_db($DBConnect, $DBName)
		Or die("<p>Unable to select the database.</p>"
		."<p>Error code ".mysqli_errno($DBConnect)
		.": ".mysqli_error($DBConnect))."</p>";
		
$TableName = "reservations";
$SQLstring = "SELECT * FROM $TableName";
$QueryResult = @mysqli_query($DBConnect, $SQLstring);
if(!$QueryResult){
	$SQLstring = "CREATE TABLE $TableName (
		reservationID SMALLINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
		guestID SMALLINT,
		checkin_month VARCHAR(10),
		checkin_day VARCHAR(10),
		checkin_year VARCHAR(10),
		room_type VARCHAR(10),
		number_nights SMALLINT,
		number_guests SMALLINT,
		discount VARCHAR(10),
		price VARCHAR(20))";
	$QueryResult = @mysqli_query($DBConnect, $SQLstring)
		Or die("<p>Unable to execute the query.</p>"
		."<p>Error code ".mysqli_errno($DBConnect)
		.": ".mysqli_error($DBConnect))."</p>";
	echo "<p>Succesfully created $TableName table.</p>";
}
$SQLstring = "INSERT INTO $TableName VALUES(
	NULL,
	'$GuestID',
	'$Month',
	'$Day',
	'$Year',
	'$RoomType',
	'$NumNights',
	'$NumGuests',
	'$Discount',
	'$Price')";
	
$QueryResult = @mysqli_query($DBConnect, $SQLstring)
		Or die("<p>Unable to execute the query.</p>"
		."<p>Error code ".mysqli_errno($DBConnect)
		.": ".mysqli_error($DBConnect))."</p>";
$_SESSION['reservationID'] = mysqli_insert_id($DBConnect);
mysqli_close($DBConnect);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Hotel Gosselin</title>
<link rel = "stylesheet" href="php_styles.css" type = "text/css" />
<meta http-equiv="content-type"
content="text/html; charset = iso-8859-1"/>
</head>
<body>
<h1>Hotel Gosselin</h1>
<h2>Reservation Confirmed</h2>
<p>Your reservation ID is <strong>
<?= $_SESSION['reservationID'] ?></strong>.</p>
<p><a href='<?php echo "FrontDesk.php?"
. SID ?>'>Front Desk</a></p>
</body>
</html>