<?php
session_start();
if(!isset($_SESSION['guestID']))
	header("location:HotelGosselin.php");
$GuestID = $_SESSION['guestID'];
if(empty($_POST['reservationID']))
	exit("<p>You must enter a reservation ID in the Cance Reservation form! Click your browsers back button to return to the previous page.</p>");
$_SESSION['reservationID'] = $_POST['reservationID'];
$ReservationID = $_POST['reservationID'];
$DBConnect = @mysqli_connect("localhost", "klince", "mvcc")
	Or die("<p>Unable to connect to the database server.</p>"
	."<p>Error code ".mysqli_connect_errno()
	.": ".mysqli_connect_error())."</p>";
$DBName = "hotel_gosselin";
@mysqli_select_db($DBConnect, $DBName)
		Or die("<p>Unable to select the database.</p>"
		."<p>Error code ".mysqli_errno($DBConnect)
		.": ".mysqli_error($DBConnect))."</p>";
$TableName = "guests";
$SQLstring = "SELECT * FROM $TableName WHERE guestID='{$_SESSION['guestID']}'";
$QueryResult = @mysqli_query($DBConnect, $SQLstring)
		Or die("<p>Unable to execute the query.</p>"
		."<p>Error code ".mysqli_errno($DBConnect)
		.": ".mysqli_error($DBConnect))."</p>";
if(mysqli_num_rows($QueryResult) > 0){
	$Row = mysqli_fetch_row($QueryResult);
	$First = stripslashes($Row[3]);
	$Last = stripslashes($Row[4]);
	mysqli_free_result($QueryResult);
}
else
	exit("<p>No result returned! Invalid guest ID.</p>");

$TableName = "reservations";
$SQLstring = "SELECT * FROM $TableName WHERE reservationID='$ReservationID' AND guestID = '$GuestID'";
$QueryResult = @mysqli_query($DBConnect, $SQLstring)
		Or die("<p>Unable to execute the query.</p>"
		."<p>Error code ".mysqli_errno($DBConnect)
		.": ".mysqli_error($DBConnect))."</p>";
if(mysqli_num_rows($QueryResult) > 0){
	$Row = mysqli_fetch_row($QueryResult);
	$Month = $Row[2];
	$Day = $Row[3];
	$Year = $Row[4];
	$Room = $Row[5];
	$Nights = $Row[6];
	$People = $Row[7];
	$Discount = $Row[8];
	$Price = $Row[9];
}
else
	exit("<p>No result returned! Invalid reservation ID.</p>");
mysqli_close($DBConnect);
?>
<script type="text/javascript">
<!--HIDE FROM INCOMPATIBLE BROWSERS
function UpdatePrice(){
	var roomRate = 100;
	if(document.forms[0].room_type[1].checked == true)
		roomRate = 150;
	else if (document.forms[0].room_type[2].checked == true)
		roomRate = 200;
	roomRate *= document.forms[0].number_nights.value;
	roomRate += (document.forms[0].number_guests.value *25);
	if(document.forms[0].discount.value != "None")
		roomRate = roomRate / 1.1;
	document.forms[0].price.value = "$" + roomRate.toFixed(2);
}
//STOP HIDING FROM INCOMPATIBLE BROWSERS -->
</script>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Hotel Gosselin</title>
<link rel = "stylesheet" href="php_styles.css" type = "text/css" />
</head>
<body onLoad="UpdatePrice();">
<h1>Hotel Gosselin</h1>
<h2>Change Reservation</h2>
<p><strong>Guest ID </strong>: <?= $GuestID ?><br />
<strong>ReservationID</strong>: <?= $ReservationID ?> <br />
<strong>Guest Name </strong>: <?= "$First $Last" ?>
</p>
<form action="DoChange.php" method="post" >
<p>Check In Month <input type="text" name="checkin_month" value='<?= $Month ?>' /><br />
Check In Day <input type="text" name="checkin_day" value='<?= $Day ?>' /><br />
Check In Day <input type="text" name="checkin_Year" value='<?= $Year ?>' /></p>

<?php
if($Room == "standard")
	echo "<p><input type = 'radio' name = 'room_type' value = 'standard' checked = 'checked onchange = 'return UpdatePrice();' />Standard Room&nbsp;
	<input type='radio' name='room_type' value='junior' onchange='return UpdatePrice();' />Junior Suite &nbsp;
	<input type='radio' name='room_type' value='suite' onchange='return UpdatePrice();' />Full Suite</p>";
else if($Room == "junior")
	echo "<p><input type = 'radio' name = 'room_type' value = 'standard' checked = 'checked onchange = 'return UpdatePrice();' />Standard Room&nbsp;
	<input type='radio' name='room_type' value='junior' onchange='return UpdatePrice();' />Junior Suite &nbsp;
	<input type='radio' name='room_type' value='suite' onchange='return UpdatePrice();' />Full Suite</p>";
else if($Room == "suite")
	echo "<p><input type = 'radio' name = 'room_type' value = 'standard' checked = 'checked onchange = 'return UpdatePrice();' />Standard Room&nbsp;
	<input type='radio' name='room_type' value='junior' onchange='return UpdatePrice();' />Junior Suite &nbsp;
	<input type='radio' name='room_type' value='suite' onchange='return UpdatePrice();' />Full Suite</p>";
?>
<p>No. of Nights&nbsp; <input name="number_nights" value='<?= $Nights ?>' size="10" onChange="return UpdatePrice();" /></p>
<p>No. of People&nbsp; <input name="number_guests" value='<?= $People ?>' size="10" onChange="return UpdatePrice();" />($25 per guest)</p>

<?php
if($Discount == "None")
	echo "<p>Discount <select name='discount' onChange = 'return UpdatePrice();'>
	<option value='None' selected = 'selected'>None</option>
	<option value='Corporate' >Corporate</option>
	<option value='AAA' >AAA</option>
	<option value='AARP' >AARP</option>
	</select>(10% off)</p>";
else if($Discount == "Corporate")
	echo "<p>Discount <select name='discount' onChange = 'return UpdatePrice();'>
	<option value='None'>None</option>
	<option value='Corporate' >Corporate</option>
	<option value='AAA' >AAA</option>
	<option value='AARP' >AARP</option>
	</select>(10% off)</p>";
else if($Discount == "AAA")
	echo "<p>Discount <select name='discount' onChange = 'return UpdatePrice();'>
	<option value='None'>None</option>
	<option value='Corporate' >Corporate</option>
	<option value='AAA' >AAA</option>
	<option value='AARP' >AARP</option>
	</select>(10% off)</p>";
else if($Discount == "AARP")
	echo "<p>Discount <select name='discount' onChange = 'return UpdatePrice();'>
	<option value='None'>None</option>
	<option value='Corporate' >Corporate</option>
	<option value='AAA' >AAA</option>
	<option value='AARP' >AARP</option>
	</select>(10% off)</p>";
?>
<p>Price: <input type="text" name="price" value="0"/></p>
<p><input type="submit" value="Change Reservation"/>
<input type="reset"/><input type="hidden" name="PHPSESSID"
value='<?php echo session_ID()?>'/></p>
</form>
<p><a href='<?php echo "FrontDesk.php?"
. SID ?>'>Front Desk</a></p>
</body>
</html>