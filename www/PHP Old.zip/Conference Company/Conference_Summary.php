<?php
session_start();
if (isset($_POST['javascript']))
	$_SESSION['javascript_seminar'] = true;
else
	$_SESSION['javascript_seminar'] = false;	
if (isset($_POST['php']))
	$_SESSION['php_seminar'] = true;
else
	$_SESSION['php_seminar'] = false;	
if (isset($_POST['mysql']))
	$_SESSION['mysql_seminar'] = true;
else
	$_SESSION['mysqli_seminar'] = false;
	
if (isset($_POST['apache']))
	$_SESSION['apache_seminar'] = true;
else
	$_SESSION['apache_seminar'] = false;
	
if (isset($_POST['web_services']))
	$_SESSION['web_services_seminar'] = true;
else
	$_SESSION['web_services_seminar'] = false;
$Required = "<span style='color:red'>**REQUIRED**</span>";
$Missing = FALSE;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
<title>Professional Conference</title>
</head>
<body>
<h1>Summary</h1>
<p>You entered the following information.</p>
<table border="1" cellpadding="5">
<tr valign="top"><td>
<h2><a href="Conference_Start.php">Personal Information</a></h2>
<?php
if (isset($_SESSION['firstName']))
	echo "<p>First Name: {$_SESSION['firstName']}<br />";
else {
	echo "<p>First Name: $Required<br />";
	$Missing = true;
}
if (isset($_SESSION['lasttName']))
	echo "<p>Last Name: {$_SESSION['lastName']}<br />";
else {
	echo "<p>Last Name: $Required<br />";
	$Missing = true;
}
if (isset($_SESSION['address']))
	echo "<p>Address: {$_SESSION['address']}<br />";
else {
	echo "<p>Address: $Required<br />";
	$Missing = true;
}
if (isset($_SESSION['city']))
	echo "<p>City: {$_SESSION['city']}<br />";
else {
	echo "<p>City: $Required<br />";
	$Missing = true;
}
if (isset($_SESSION['state']))
	echo "<p>State: {$_SESSION['state']}<br />";
else {
	echo "<p>State: $Required<br />";
	$Missing = true;
}
if (isset($_SESSION['zip']))
	echo "<p>Zip: {$_SESSION['zip']}<br />";
else {
	echo "<p>Zip: $Required<br />";
	$Missing = true;
}
if (isset($_SESSION['phone']))
	echo "<p>Phone: {$_SESSION['phone']}<br />";
else {
	echo "<p>Phone: $Required<br />";
	$Missing = true;
}
if (isset($_SESSION['email']))
	echo "<p>Email: {$_SESSION['email']}<br />";
else {
	echo "<p>Email: $Required<br />";
	$Missing = true;
}
?>
</td>
<td><h2><a href="Conference_Company.php">Company Information</a></h2>
<?php
if (isset($_SESSION['company']))
	echo "<p>Company: {$_SESSION['company']}<br />";
else {
	echo "<p>Company: $Required<br />";
	$Missing = true;
}
if (isset($_SESSION['co_address']))
	echo "<p>Address: {$_SESSION['co_address']}<br />";
else {
	echo "<p>Address: $Required<br />";
	$Missing = true;
}
if (isset($_SESSION['co_city']))
	echo "<p>City: {$_SESSION['co_city']}<br />";
else {
	echo "<p>City: $Required<br />";
	$Missing = true;
}
if (isset($_SESSION['co_state']))
	echo "<p>State: {$_SESSION['co_state']}<br />";
else {
	echo "<p>State: $Required<br />";
	$Missing = true;
}
if (isset($_SESSION['co_zip']))
	echo "<p>Zip: {$_SESSION['co_zip']}<br />";
else {
	echo "<p>Zip: $Required<br />";
	$Missing = true;
}
if (isset($_SESSION['co_phone']))
	echo "<p>Phone: {$_SESSION['co_phone']}<br />";
else {
	echo "<p>Phone: $Required<br />";
	$Missing = true;
}
?>
</td>
<td><h2><a href="Conference_Seminars.php">Seminars</a></h2>
<?php
if ($_SESSION['javascript_seminar'] == true)
	echo "<p>JavaScript seminar: yes<br />";
else
	echo "<p>JavaScript seminar: no<br />";
if ($_SESSION['php_seminar'] == true)
	echo "<p>PHP seminar: yes<br />";
else
	echo "<p>PHP seminar: no<br />";
if ($_SESSION['mysql_seminar'] == true)
	echo "<p>MySQL seminar: yes<br />";
else
	echo "<p>MySQL seminar: no<br />";
if ($_SESSION['apache_seminar'] == true)
	echo "<p>Apache seminar: yes<br />";
else
	echo "<p>Apache seminar: no<br />";
if ($_SESSION['web_services_seminar'] == true)
	echo "<p>Web Services seminar: yes<br />";
else
	echo "<p>Web Services seminar: no<br />";
?>
</td></tr></table>
<?php
if ($Missing)
	echo "<p><span style='color:red'> You cannot register for the conference until you fill out all **REQUIRED** fields!</span></p>";
else
	echo "<form action='Conference_Register.php' method='post'>
	<p><input type='submit' value='Register' /></p></form>";
?>
<form action="Conference_Seminars.php" method="post">
<p><input type="submit" value="Back" /></p>
</form>
<form action="Conference_Restart.php" method="post">
<p><input type="submit" value="Start Over" /></p>
</form>
</body>
</body>
</html>