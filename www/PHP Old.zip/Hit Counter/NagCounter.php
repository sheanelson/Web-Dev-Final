<?php
if(isset($_COOKIE['registered'])){
	$Visitor = $_COOKIE['registered'][0];
	$Email = $_COOKIE['registered'][1];
	echo "<p>Welcome back $Visitor! Your e-mail address is $Email.</p>";
}
else if (isset($_GET['name']) && isset($_GET['email'])){
	setcookie("registered[0]", $_GET['name']);
	setcookie("registered[1]", $_GET['email']);
	setcookie("counter", "", time()-3600);
	echo "<p>Thanks for registering!</p>";
}
else {
	$Counter = 1;
	$Nag = FALSE;
	if (isset($_COOKIE['counter'])){
		$Counter = $_COOKIE['counter'];
		if ($Counter > 4){
			$Nag = TRUE;
			$Counter = 1;
		}
		else
			++$Counter;
	}
	setcookie("counter", $Counter, time()+60*60*24*7*52);
	if ($Nag)
		echo "<p>Please take a moment to register!</p>";
		
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-Strict.dtd">
<html>
<head>
<title>Nag Counter</title>
</head>
<body>
<h3>Registration</h3>
<form action="NagCounter.php" method="get">
<p><b>Please take a moment to register.</b></p>
<p><b>Please Enter Your Name</b></p>
<input name="name" size="50" /></p>
<p><b>Please Enter Your Email Address</b><br />
<input name="email" size="100" /></p>
<p><input type="submit" value="Register" /></p>
</form>
</body>
</html>
