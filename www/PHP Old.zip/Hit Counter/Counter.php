<?php
if(isset($_Get['name'])){
	$Visitor = $_Get['name'];
	$Visits = 1;
	if(isset($_COOKIE[$_Get['name']])){
		$Visits = $_COOKIE[$_GET['name']];
		++$Visits;
	}
	setcookie($_GET['name'], $Visits, time()+60*60*24*7*52);
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
<title>Visit Counter</title>
<?php
if (isset($_GET['name'])){
	echo "<p>Welcome back $Visitor! Number of visits: $Visits.";
}
?>
</head>
<body>
<h3>Visit Counter</h3>
<form action="Counter.php" method="get">
<p><b>Please Enter Your Name</b><br />
<input type="text" name="name" size="50" /><input type="submit"
value="Submit" /></p>
</form
</body>
</html>