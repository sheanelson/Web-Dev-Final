<?php
require_once("ShoppingCart.php");
session_start();
if(!isset($_SESSION['curCart']))
	header("location:GosselinGourmetGoods.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Gosselin Gourmet Goods</title>
<meta http-equiv="Content-Type" 
content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="php_styles.css" type="text/css" />
</head>
<body>
<h1>Gosselin Gourmet</h1>
<h2>Shop by Category</h2>
<p><a href='<?php echo "GosselinGourmetCoffees.php?PHPSESSID=" .session_id() ?>'>Gourmet Coffees</a><br/>
<a href='<?php echo "GosselinGourmetOlives.php?PHPSESSID=" .session_id() ?>'>Gourmet Olives</a><br/>
<a href='<?php echo "GosselinGourmetSpices.php?PHPSESSID=" .session_id() ?>'>Gourmet Spices</a></p>
<h2>Your Shopping Cart</h2>
<?php
$Cart = unserialize($_SESSION['curCart']);
if (isset($_GET['operation'])){
	if ($_GET['operation'] == "addItem")
		$Cart->addItem();
	if ($_GET['operation'] == "removeItem")
		$Cart->removeItem();
	if ($_GET['operation'] == "emptyCart")
		$Cart->emptyCart();
	if ($_GET['operation'] == "addOne")
		$Cart->addOne();
	if ($_GET['operation'] == "removeOne")
		$Cart->removeOne();
}
$Cart->showCart();
$_SESSION['curCart'] = serialize($Cart);
?>
<p><a href='<?php echo "Checkout.php?PHPSESSID=" . session_id() . "&operation=checkout&productID=" . $_GET["productID"] ?>'>Checkout</a></p>
<p><a href="GosselinGourmetGoods.php">Cancel Order</a></p>
</body>
</html>