<?php
class ShoppingCart {
	private $DBConnect;
	private $DBName = "";
	private $TableName = "";
	private $Orders = array();
	private $OrdersTable = array();
	function __construct() {
		$this->DBConnect = @mysqli("localhost", "csleys", "mvcc");
		if (mysqli_connect_errno())
			die("<p>Unable to connect to the database server.</p>"
			."<p>Error code " .mysqli_connect_errno()
			.":".mysqli_connect_error()). "</p>";
	}
	function __destruct() {
		$this->DBConnect->close();
	}
	public function setDatabase($Database) {
		$this->DBName = $Database;
		@$this->DBConnect->select_db($this->DBName)
		Or die("<p>Unable to select the database.</p>"
		."<p>Error code " .mysqli_errno($this->DBConnect)
		.":".mysqli_error($this->DBConnect)). "</p>";
	}
	public function setTable($Table) {
		$this->TableName = $Table;
	}
	public function getProductList() {
		$SQLstring = "SELECT * FROM $this->TableName";
		$QueryResult = $this->DBConnect->query($SQLstring)
		or die("<p>Unable to perform the query.</p>"
		."<p>Error code" .mysqli_errno($this->DBConnect)
		.":".mysqli_error($DBConnect)). "</p>";
		echo "<table width='100%' border='1'>";
		echo "<tr><th>Product</th><th>Description</th></tr>
		<th>Price Each</th><th>Select item</th></tr>";
		$Row = $QueryResult->fetch_row();
		do {
			echo "<tr><td>{Row[1]}</td>";
			echo "<td>{Row[2]}</td>";
			printf("<td align='center'>$%.2f</td>", $Row[3]);
			echo "<td align='center'><a href='ShowCart.php?PHPSESSID=" .session_id(). "&operation=additem&productID=" .$Row[0]. "'>Add</a></td></tr>";
			$Row = $QueryResult->fetch_row();
		} while ($Row);
		echo "</table>";
	}
	public function addItem() {
		$ProdID = $_GET['productID'];
		if (array_key_exists($ProdID, $this->Orders))
			exit("<p>You already selected that item! Click your browser's back button to return to the previous page. </p>");
			$this->Orders[$ProdID] = 1;
			$this->OrderTable[$ProdID] = $this->TableName;
	}
	function __wakeup() {
		$this->DBConnect = @new mysqli("localhost", "klince", "mvcc");
		if (mysqli_connect_errno())
			die("<p>Unable to connect to the database server.</p>"
			."<p>Error code " .mysqli_connect_errno()
			.":" .mysqli_connect_error()). "</p>";
		@$this->DBConnect->select_db($this->DBName)
			or die("<p>Unable to select the database.</p>"
			."<p>Error code " .mysqli_errno($this->DBConnect)
			.":" .mysqli_error($this->DBConnect)). "</p>";
	}
	public function showCart() {
		if (empty($this->Orders))
			echo "<p>Your shopping cart is empty!</p>";
		else {
			echo "<table width='100%' border='1'>";
			echo "<tr><th>Remove Item</th><th>Product</th><th>Quantity</th><th>Price Each</th></tr>";
			$Total = 0;
			foreach ($this->Orders as $Order) {
				$SQLstring = "SELECT * FROM " .$this->OrderTable[key($this->Orders)]. "WHERE productID='" .key($this->Orders). "'";
				$QueryResult = @mysqli_query($this->DBConnect, $SQLstring)
				or die("<p>Unable to perform the query.</p>"
				."<p>Error code " .mysqli_errno($this->DBConnect)				
				.":" .mysqli_error($this->DBConnect)). "</p>";
				$Row = mysqli_fetch_row($QueryResult);
				echo "<td align='center'>";
				echo "<a href='ShowCart.php?PHPSESSID=" . session_id() . "&operation=removeItem&productID=" . $Row[0] . "'> Remove</a></td>";
				echo "<td>{$Row[1]}</td>";
				echo "<td align='center'>$Order";
				echo "<a href='ShowCart.php?PHPSESSID=" . session_id() . "&operation=addOne&productID=" . $Row[0] . "'> Add</a></td>";
				echo "<a href='ShowCart.php?PHPSESSID=" . session_id() . "&operation=removeOne&productID=" . $Row[0] . "'> Remove</a></td>";
				echo "</td>";
				printf("<td align='center'>$%.2f</td></tr>", $Row[3]);
				$Total += $Row[3] * $Order;
				next($this->Orders);
			}
			echo "<tr><td align='center'><a href='ShowCart.php?PHPSESSID=" . session_id() . "&operation=emptyCart'><strong>Empty Cart</strong></a></td>";
			echo "<td align='center' colspan='2'><strong>Your shopping cart containts " .count($this->Orders) . " product(s).</strong></td>";
			printf("<td align='center'<strong>Total: $%.2f</strong></td>", $Total);
			echo "</table>";
		}
	}
	public function removeItem() {
		$ProdID = $_GET['productID'];
		unset($this->Orders[$ProdID]);
		unset($this->OrdersTable[$ProdID]);
	}
	public function emptyCart() {
		$this->Orders = array();
		$this->OrdersTable = array();
	}
	public function addOne() {
		$ProdID = $_GET['productID'];
		$this->Orders[$ProdID] +=1;
	}
	public function removeOne() {
		$ProdID = $_GET['productID'];
		$this->Orders[$ProdID] -=1;
		if ($this->Orders[$ProdID] == 0)
		$this->removeItem();
	}
	public function checkout() {
		$ProdID = $_GET['productID'];
		foreach ($this->Orders as $Order) {
			$SQLstring = "INSERT INTO " . $this->TableName . " VALUES('" . session_id() . "', '" .key($this->Orders) . "', '" . $this->OrderTable[key($this->Orders)] . "', " . $Order . ")";
			$QueryResult = @mysqli_query($this->DBConnect, $SQLstring)
			or die("<p>Unable to perform the query.</p>"
			."<p>Error code " .mysqli_errno($this->DBConnect)
			.":" . mysqli_error($this->DBConnect)) . "</p>";
			next($this->Orders);
		}
		echo "<p><strong>Your order is confrimed.</strong></p>";
	}
}
?>

				
				