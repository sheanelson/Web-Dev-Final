<?php
require_once("ShoppingCart.php");
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-Strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Gosselin Gourmet Goods</title>
<meta http-equiv="Content-Type" 
content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="php_styles.css" type="text/css" />
</head>
<body>
<h1>Gosselin Gourmet Goods</h1>
<h2>Shop by Category</h2>
<p><a href='<?php echo "GosselinGourmetCoffees.php?PHPSESSID=" . session_id() ?>'>Gourmet Coffees</a><br />
<a href='<?php echo "GosselinGourmetOlives.php?PHPSESSID=" . session_id() ?>'>Specialty Olives</a><br />
<a href='<?php echo "GosselinGourmetSpices.php?PHPSESSID=" . session_id() ?>'>Gourmet Spices</a></p>
<h2>Gourmet Coffees</h2>
<?php
$Database = "gosselin_gourmet";
$Table = "coffee";
if (isset($_SESSION['curCart']))
	$Cart = unserialize($_SESSION['curCart']);
else {
	if (class_exists("ShoppingCart")){
		$Cart = new ShoppingCart();
		$Cart->setDatabase($Database);
	}
	else
		exit("<p>The ShoppingCart class is not available!</p>");
}
$Cart->setTable($Table);
$Cart->getProductList();
$_SESSION['curCart'] = serialize($Cart);
?>
<p><a href='<?php echo "ShowCart.php?PHPSESSID=" . session_id() ?>'>Show Shopping Cart</a></p>
</body>
</html>