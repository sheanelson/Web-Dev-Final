<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Arithmatic Examples.php</title>
</head>

<body>
<?php
$Number = 100;
$Result = 0;
$Result = $Number + 50;
echo '<p>$Result after addition = ', $Result,"<br/>";
$Result = $Number/4;
echo '<p>$Result after division = ', $Result,"<br/>";
$Result = $Number - 25;
echo '<p>$Result after subtraction = ', $Result,"<br/>";
$Result = $Number * 2;
echo '<p>$Result after multiplication = ', $Result,"<br/>";
$Result = ++$Number;
echo '<p>$Result after increment = ', $Result,"<br/>";
?>
</body>
</html>