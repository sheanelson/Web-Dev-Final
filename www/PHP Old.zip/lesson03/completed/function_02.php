<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Using a function and capturing the result</title>
<link href="../../styles/examples.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Changing a Value Permanently</h1>
<?php $name = 'David'; ?>
<p>$name is <?php echo $name; ?></p>
<p>$name_upper = strtoupper($name); <?php $name_upper = strtoupper($name); ?></p>
<p>$name_upper is <?php echo $name_upper; ?></p>
<p>$name is <?php echo $name; ?></p>
<p>$name = strtoupper($name); <?php $name = strtoupper($name); ?></p>
<p>$name_upper is <?php echo $name_upper; ?></p>
<p>$name is <?php echo $name; ?></p>
<p>upcase(hello) =  <? echo upcase("hello") ?></p>
<? echo $time = new DateTime(); ?>
<p>Current date time is <? echo DateTime::createFromFormat(U, $time); ?></p>
</body>

<?
function upcase($str)
{
	return strtoupper($str);	
}
?>

<?
function to_string($str)
{
	return strtoupper($str);	
}
?>


</html>