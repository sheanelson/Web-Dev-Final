<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Decimal Variables</title>
</head>

<body>
<?php
$MortgageInterest = .08;
$AutoInterest = .055;
$CreditCardInterest = .16;
echo "<p>My mortgage interst rate is ";
echo $MortgageInterest,".<br/>";
echo '$MortgageInterest is of the ' ;
echo gettype($MortgageInterest)," data type. <br/>";
echo "My auto interest rate is " ;
echo $AutoInterest, ".<br/>";
echo '$AutoInterest is of the ';
echo gettype($AutoInterest), " data type.<br/>";
echo "My credit card interest rate is ";
echo $CreditCardInterest ,".<br/>";
echo '$CreditCardInterest is of the ';
echo gettype($CreditCardInterest )," data type.</p>";
?>
</body>
</html>