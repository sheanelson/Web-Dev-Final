-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 10, 2010 at 11:20 AM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `phpcs5`
--

-- --------------------------------------------------------

--
-- Table structure for table `photos`
--

DROP TABLE IF EXISTS `photos`;
CREATE TABLE IF NOT EXISTS `photos` (
  `photo_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `filename` varchar(30) NOT NULL,
  `caption` varchar(150) NOT NULL,
  PRIMARY KEY (`photo_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `photos`
--

INSERT INTO `photos` (`photo_id`, `filename`, `caption`) VALUES
(1, 'sanfrancisco1.jpg', 'Cable car'),
(2, 'sanfrancisco2.jpg', 'Golden Gate Bridge'),
(3, 'grandcanyon1.jpg', 'View from Bright Angel Point (North Rim)'),
(4, 'grandcanyon2.jpg', 'View from Point Imperial (North Rim)'),
(5, 'lasvegas1.jpg', 'Get rich quick - maybe'),
(6, 'lasvegas2.jpg', 'New York - no, not really'),
(7, 'losangeles1.jpg', 'Grauman''s Chinese Theater on Hollywood Boulevard'),
(8, 'joshuatree1.jpg', 'View from summit of Ryan Mountain'),
(9, 'joshuatree2.jpg', 'Hidden valley'),
(10, 'newportbeach1.jpg', 'Balboa Island'),
(11, 'newportbeach2.jpg', 'Marina on Balboa Island'),
(12, 'sanjose1.jpg', 'Making a splash in the Plaza de Cesar Chavez'),
(13, 'sanjose2.jpg', 'Canada geese in the Guadalupe River Park'),
(14, 'longbeach1.jpg', 'Queen Mary at her berth'),
(15, 'longbeach2.jpg', 'Shoreline Aquatic Park'),
(16, 'bryce1.jpg', 'The natural amphitheater seen from the rim'),
(17, 'bryce2.jpg', 'Down among the hoodoos'),
(18, 'zion1.jpg', 'Towering cliff and natural arch below'),
(19, 'zion2.jpg', 'View from Zion-Mount Carmel Highway'),
(20, 'losangeles2.jpg', 'All that remains of the original Spanish pueblo is souvenir stalls');

-- --------------------------------------------------------

--
-- Table structure for table `place2photo`
--

DROP TABLE IF EXISTS `place2photo`;
CREATE TABLE IF NOT EXISTS `place2photo` (
  `place_id` int(10) unsigned NOT NULL,
  `photo_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`place_id`,`photo_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `place2photo`
--

INSERT INTO `place2photo` (`place_id`, `photo_id`) VALUES
(1, 1),
(1, 2),
(2, 3),
(2, 4),
(3, 5),
(3, 6),
(4, 7),
(5, 8),
(5, 9),
(6, 10),
(6, 11),
(7, 12),
(7, 13),
(8, 14),
(8, 15),
(9, 16),
(9, 17),
(10, 18),
(10, 19),
(11, 7),
(11, 20);

-- --------------------------------------------------------

--
-- Table structure for table `places`
--

DROP TABLE IF EXISTS `places`;
CREATE TABLE IF NOT EXISTS `places` (
  `place_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `state_id` char(2) NOT NULL,
  `name` varchar(60) NOT NULL,
  `description` text NOT NULL,
  `link_name` varchar(60) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`place_id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `link_name` (`link_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `places`
--

INSERT INTO `places` (`place_id`, `state_id`, `name`, `description`, `link_name`, `updated`, `created`) VALUES
(1, 'CA', 'San Francisco', 'The hilly city that Dreamweaver calls home. There are more than 50 hills within the city limits. The tallest, Mount Davidson, rises 925 feet (282 m). San Francisco''s steep hills gave rise to the cable car system, which began operation in 1873. Only three lines are still in operation, but they remain a great favorite with tourists.\r\n\r\nUt labore et dolore magna aliqua. Quis nostrud exercitation excepteur sint occaecat qui officia deserunt. Sed do eiusmod tempor incididunt cupidatat non proident, velit esse cillum dolore. Ut aliquip ex ea commodo consequat.\r\n\r\nEu fugiat nulla pariatur. In reprehenderit in voluptate. Lorem ipsum dolor sit amet, ullamco laboris nisi sed do eiusmod tempor incididunt. Sunt in culpa ut enim ad minim veniam, velit esse cillum dolore. Eu fugiat nulla pariatur.\r\n\r\nUt labore et dolore magna aliqua. Qui officia deserunt ut aliquip ex ea commodo consequat. Quis nostrud exercitation ullamco laboris nisi velit esse cillum dolore. Eu fugiat nulla pariatur.\r\n\r\nIn reprehenderit in voluptate cupidatat non proident, quis nostrud exercitation. Ut aliquip ex ea commodo consequat. In reprehenderit in voluptate lorem ipsum dolor sit amet, ut enim ad minim veniam. Quis nostrud exercitation eu fugiat nulla pariatur. Ut aliquip ex ea commodo consequat.', 'SF', '2010-06-10 11:05:19', '2010-05-25 10:04:57'),
(2, 'AZ', 'Grand Canyon', 'Nothing can really prepare you for that moment when you first step up to the edge of the Grand Canyon. It''s a truly jaw-dropping experience. The North Rim rises a thousand feet (more than 300 meters) higher than the South Rim, and is heavily forested. After driving through lush grassland and winding forest roads, the Canyon suddenly opens up before you.\r\n\r\nIn 1903, President Theodore Roosevelt urged fellow Americans to "Leave it as it is. You cannot improve on it. The ages have been at work on it, and only man can mar it." For the most part, his words have been heeded.\r\n\r\nLorem ipsum dolor sit amet, ut enim ad minim veniam, duis aute irure dolor. In reprehenderit in voluptate velit esse cillum dolore cupidatat non proident. Mollit anim id est laborum.\r\n\r\nUt labore et dolore magna aliqua. Qui officia deserunt ut aliquip ex ea commodo consequat. Quis nostrud exercitation ullamco laboris nisi velit esse cillum dolore. Eu fugiat nulla pariatur.\r\n\r\nIn reprehenderit in voluptate cupidatat non proident, quis nostrud exercitation. Ut aliquip ex ea commodo consequat. In reprehenderit in voluptate lorem ipsum dolor sit amet, ut enim ad minim veniam. Quis nostrud exercitation eu fugiat nulla pariatur. Ut aliquip ex ea commodo consequat.', 'GrandCanyon', '2010-06-06 17:22:24', '2010-06-06 17:12:47'),
(3, 'NV', 'Las Vegas', 'Las Vegas is a city you either love or hateâ€”there''s no in between. It''s brash, it''s noisy. It''s where you go to let your hair down, and blow the consequences. As the saying goes, "What happens in Vegas, stays in Vegas." All too often, that''s what happens to your money, too. Many are unable to resist the lure of the slot machines, roulette tables, and blackjack tables in the hope of getting rich quick.\r\n\r\nIt''s also a place for great entertainment. Most of the big hotels have theaters and cabarets that attract some of the world''s biggest stars. Eu fugiat nulla pariatur. In reprehenderit in voluptate. Lorem ipsum dolor sit amet, ullamco laboris nisi sed do eiusmod tempor incididunt. Sunt in culpa ut enim ad minim veniam, velit esse cillum dolore. Eu fugiat nulla pariatur.\r\n\r\nIn reprehenderit in voluptate cupidatat non proident, quis nostrud exercitation. Ut aliquip ex ea commodo consequat. In reprehenderit in voluptate lorem ipsum dolor sit amet, ut enim ad minim veniam. Quis nostrud exercitation eu fugiat nulla pariatur. Ut aliquip ex ea commodo consequat.\r\nUt labore et dolore magna aliqua. Qui officia deserunt ut aliquip ex ea commodo consequat. Quis nostrud exercitation ullamco laboris nisi velit esse cillum dolore. Eu fugiat nulla pariatur.', 'LasVegas', '2010-06-10 11:19:26', '2010-06-06 17:21:19'),
(4, 'CA', 'Hollywood', 'If you''re a movie buff, Hollywood is likely to be high on the list of places you want to visit, but be prepared to have some of your illusions dented. A stroll along Hollywood Boulevard holds little glamor and deserves the name Tinseltown. For every well-known name in the Hollywood Walk of Fame, you ''re likely to see many more who have faded from memory. \r\n\r\nLorem ipsum dolor sit amet, ut enim ad minim veniam, duis aute irure dolor. In reprehenderit in voluptate velit esse cillum dolore cupidatat non proident. Mollit anim id est laborum.\r\n\r\nUt labore et dolore magna aliqua. Quis nostrud exercitation excepteur sint occaecat qui officia deserunt. Sed do eiusmod tempor incididunt cupidatat non proident, velit esse cillum dolore. Ut aliquip ex ea commodo consequat.\r\n\r\nEu fugiat nulla pariatur. In reprehenderit in voluptate. Lorem ipsum dolor sit amet, ullamco laboris nisi sed do eiusmod tempor incididunt. Sunt in culpa ut enim ad minim veniam, velit esse cillum dolore. Eu fugiat nulla pariatur.', 'Hollywood', '2010-06-09 17:30:47', '2010-06-06 17:58:28'),
(5, 'CA', 'Joshua Tree National Park', 'Joshua Tree National Park covers more than 1,250 square miles (3,200 sq km) of the Mojave and Colorado Deserts. The park gets its name from the large numbers of Joshua Trees (a type of yucca) in the Mojave Desert in its northern half. The northern section of the park is also notable for strange outcrops of rock and granite monoliths, whereas the southern halfâ€”which lies at a much lower elevationâ€”is more barren.\r\nIn reprehenderit in voluptate cupidatat non proident, quis nostrud exercitation. Ut aliquip ex ea commodo consequat. In reprehenderit in voluptate lorem ipsum dolor sit amet, ut enim ad minim veniam. Quis nostrud exercitation eu fugiat nulla pariatur. Ut aliquip ex ea commodo consequat.\r\n\r\nEu fugiat nulla pariatur. In reprehenderit in voluptate. Lorem ipsum dolor sit amet, ullamco laboris nisi sed do eiusmod tempor incididunt. Sunt in culpa ut enim ad minim veniam, velit esse cillum dolore. Eu fugiat nulla pariatur.\r\n\r\nUt labore et dolore magna aliqua. Qui officia deserunt ut aliquip ex ea commodo consequat. Quis nostrud exercitation ullamco laboris nisi velit esse cillum dolore. Eu fugiat nulla pariatur.', 'JoshuaTree', '2010-06-10 11:04:12', '2010-06-06 18:21:14'),
(6, 'CA', 'Newport Beach', 'Newport Beach is where the rich and famous live, yet remain within easy reach of Los Angeles. Its climate is greatly moderated by the Pacific Ocean, resulting in mild winters and relatively cool summers. Among its famous former residents is John Wayne, for whom the city''s airport is named.\r\n\r\nIn reprehenderit in voluptate cupidatat non proident, quis nostrud exercitation. Ut aliquip ex ea commodo consequat. In reprehenderit in voluptate lorem ipsum dolor sit amet, ut enim ad minim veniam. Quis nostrud exercitation eu fugiat nulla pariatur. Ut aliquip ex ea commodo consequat.\r\n\r\nEu fugiat nulla pariatur. In reprehenderit in voluptate. Lorem ipsum dolor sit amet, ullamco laboris nisi sed do eiusmod tempor incididunt. Sunt in culpa ut enim ad minim veniam, velit esse cillum dolore. Eu fugiat nulla pariatur.\r\n\r\nUt labore et dolore magna aliqua. Qui officia deserunt ut aliquip ex ea commodo consequat. Quis nostrud exercitation ullamco laboris nisi velit esse cillum dolore. Eu fugiat nulla pariatur.', 'NewportBeach', '2010-06-06 18:29:46', '2010-06-06 18:29:46'),
(7, 'CA', 'San Jose', 'San Jose is the unofficial capital of Silicon Valley, where large numbers of leading technology companiesâ€”including Adobeâ€”are headquartered. Before World War II, agriculture was the mainstay of the local economy. Among local landmarks is the Winchester Mystery House, the former home of Sarah Winchester, the widow of the gun magnate, William Wirt Winchester. She believed the house was haunted by the ghosts of people killed by Winchester rifles, and that only continuous construction of the houseâ€”which continued for 38 yearsâ€”would appease them.\r\n\r\nLorem ipsum dolor sit amet, ut enim ad minim veniam, duis aute irure dolor. In reprehenderit in voluptate velit esse cillum dolore cupidatat non proident. Mollit anim id est laborum.\r\n\r\nUt labore et dolore magna aliqua. Quis nostrud exercitation excepteur sint occaecat qui officia deserunt. Sed do eiusmod tempor incididunt cupidatat non proident, velit esse cillum dolore. Ut aliquip ex ea commodo consequat.\r\n\r\nEu fugiat nulla pariatur. In reprehenderit in voluptate. Lorem ipsum dolor sit amet, ullamco laboris nisi sed do eiusmod tempor incididunt. Sunt in culpa ut enim ad minim veniam, velit esse cillum dolore. Eu fugiat nulla pariatur.\r\n\r\nIn reprehenderit in voluptate cupidatat non proident, quis nostrud exercitation. Ut aliquip ex ea commodo consequat. In reprehenderit in voluptate lorem ipsum dolor sit amet, ut enim ad minim veniam. Quis nostrud exercitation eu fugiat nulla pariatur. Ut aliquip ex ea commodo consequat.', 'SanJose', '2010-06-06 18:52:37', '2010-06-06 18:52:37'),
(8, 'CA', 'Long Beach', 'Long Beach, 20 miles (32 km) south of Los Angeles, is the second busiest sea port in the United States, and is now home to the former Cunard liner, RMS Queen Mary. The city also has a large oil industry. Ut labore et dolore magna aliqua. Quis nostrud exercitation excepteur sint occaecat qui officia deserunt. \r\n\r\nSed do eiusmod tempor incididunt cupidatat non proident, velit esse cillum dolore. Ut aliquip ex ea commodo consequat. Eu fugiat nulla pariatur. In reprehenderit in voluptate. Lorem ipsum dolor sit amet, ullamco laboris nisi sed do eiusmod tempor incididunt. Sunt in culpa ut enim ad minim veniam, velit esse cillum dolore. Eu fugiat nulla pariatur.\r\n\r\nLorem ipsum dolor sit amet, ut enim ad minim veniam, duis aute irure dolor. In reprehenderit in voluptate velit esse cillum dolore cupidatat non proident. Mollit anim id est laborum. In reprehenderit in voluptate cupidatat non proident, quis nostrud exercitation.\r\n\r\nUt aliquip ex ea commodo consequat. In reprehenderit in voluptate lorem ipsum dolor sit amet, ut enim ad minim veniam. Quis nostrud exercitation eu fugiat nulla pariatur. Ut aliquip ex ea commodo consequat.', 'LongBeach', '2010-06-06 19:08:28', '2010-06-06 19:08:28'),
(9, 'UT', 'Bryce Canyon National Park', 'Bryce Canyon is a giant natural amphitheater filled with tall, thin spires of rockâ€”called hoodoosâ€”sculpted by water, wind, and ice erosion. The name comes from early geologists who believed that  the rock formations could cast a spell with their magical spires and towering arches. Visitors with strong legs and plenty of stamina can descend from the rim of the amphitheater to walk among the hoodoos, seeing them from a completely different perspective.\r\n\r\nLorem ipsum dolor sit amet, ut enim ad minim veniam, duis aute irure dolor. In reprehenderit in voluptate velit esse cillum dolore cupidatat non proident. Mollit anim id est laborum. In reprehenderit in voluptate cupidatat non proident, quis nostrud exercitation.\r\n\r\nUt aliquip ex ea commodo consequat. In reprehenderit in voluptate lorem ipsum dolor sit amet, ut enim ad minim veniam. Quis nostrud exercitation eu fugiat nulla pariatur. Ut aliquip ex ea commodo consequat.\r\n\r\nSed do eiusmod tempor incididunt cupidatat non proident, velit esse cillum dolore. Ut aliquip ex ea commodo consequat. Eu fugiat nulla pariatur. In reprehenderit in voluptate. Lorem ipsum dolor sit amet, ullamco laboris nisi sed do eiusmod tempor incididunt. Sunt in culpa ut enim ad minim veniam, velit esse cillum dolore. Eu fugiat nulla pariatur.', 'BryceCanyon', '2010-06-10 11:05:38', '2010-06-06 19:41:44'),
(10, 'UT', 'Zion National Park', 'Towering cliffs and natural stone arches inspire awe as you pass through lush greenery.  Zion National Park is part of a geological formation known as the Grand Staircase, which runs south from Bryce Canyon  to the Grand Canyon. The bottom layer of rock at Bryce Canyon is the top layer at Zion, and the bottom layer at Zion is the top layer at the Grand Canyon.\r\n\r\nLorem ipsum dolor sit amet, ut enim ad minim veniam, duis aute irure dolor. In reprehenderit in voluptate velit esse cillum dolore cupidatat non proident. Mollit anim id est laborum. In reprehenderit in voluptate cupidatat non proident, quis nostrud exercitation.\r\n\r\nUt aliquip ex ea commodo consequat. In reprehenderit in voluptate lorem ipsum dolor sit amet, ut enim ad minim veniam. Quis nostrud exercitation eu fugiat nulla pariatur. Ut aliquip ex ea commodo consequat.\r\n\r\nSed do eiusmod tempor incididunt cupidatat non proident, velit esse cillum dolore. Ut aliquip ex ea commodo consequat. Eu fugiat nulla pariatur. In reprehenderit in voluptate. Lorem ipsum dolor sit amet, ullamco laboris nisi sed do eiusmod tempor incididunt. Sunt in culpa ut enim ad minim veniam, velit esse cillum dolore. Eu fugiat nulla pariatur.', 'Zion', '2010-06-10 11:06:00', '2010-06-06 20:02:30'),
(11, 'CA', 'Los Angeles', 'Los Angeles is the second largest city in the United States. It''s the home of Hollywood, a major business and cultural center, and one of the most multicultural cities in the USA. The city''s Spanish name reflects its history. Originally founded in the late eighteenth century by the Spanish governor, it became part of Mexico in 1821 following Mexican independence.  In 1848, Los Angeles and the rest of California were purchased from Mexico at the end of the Mexican-American War. \r\n\r\nQuis nostrud exercitation eu fugiat nulla pariatur. Ut aliquip ex ea commodo consequat. Sed do eiusmod tempor incididunt cupidatat non proident, velit esse cillum dolore. Ut aliquip ex ea commodo consequat.\r\n\r\nEu fugiat nulla pariatur. In reprehenderit in voluptate. Lorem ipsum dolor sit amet, ullamco laboris nisi sed do eiusmod tempor incididunt. Sunt in culpa ut enim ad minim veniam, velit esse cillum dolore. Ut aliquip ex ea commodo consequat. In reprehenderit in voluptate lorem ipsum dolor sit amet, ut enim ad minim veniam.\r\n\r\nLorem ipsum dolor sit amet, ut enim ad minim veniam, duis aute irure dolor. In reprehenderit in voluptate velit esse cillum dolore cupidatat non proident. Mollit anim id est laborum. In reprehenderit in voluptate cupidatat non proident, quis nostrud exercitation.', 'LA', '2010-06-10 11:04:51', '2010-06-06 20:16:50');

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

DROP TABLE IF EXISTS `states`;
CREATE TABLE IF NOT EXISTS `states` (
  `state_id` char(2) NOT NULL,
  `state_name` varchar(25) NOT NULL,
  PRIMARY KEY (`state_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`state_id`, `state_name`) VALUES
('AK', 'Alaska'),
('AL', 'Alabama'),
('AR', 'Arkansas'),
('AZ', 'Arizona'),
('CA', 'California'),
('CO', 'Colorado'),
('CT', 'Connecticut'),
('DC', 'District of Columbia'),
('DE', 'Delaware'),
('FL', 'Florida'),
('GA', 'Georgia'),
('HI', 'Hawaii'),
('IA', 'Iowa'),
('ID', 'Idaho'),
('IL', 'Illinois'),
('IN', 'Indiana'),
('KS', 'Kansas'),
('KY', 'Kentucky'),
('LA', 'Louisiana'),
('MA', 'Massachusetts'),
('MD', 'Maryland'),
('ME', 'Maine'),
('MI', 'Michigan'),
('MN', 'Minnesota'),
('MO', 'Missouri'),
('MS', 'Mississippi'),
('MT', 'Montana'),
('NC', 'North Carolina'),
('ND', 'North Dakota'),
('NE', 'Nebraska'),
('NH', 'New Hampshire'),
('NJ', 'New Jersey'),
('NM', 'New Mexico'),
('NV', 'Nevada'),
('NY', 'New York'),
('OH', 'Ohio'),
('OK', 'Oklahoma'),
('OR', 'Oregon'),
('PA', 'Pennsylvania'),
('RI', 'Rhode Island'),
('SC', 'South Carolina'),
('SD', 'South Dakota'),
('TN', 'Tennessee'),
('TX', 'Texas'),
('UT', 'Utah'),
('VA', 'Virginia'),
('VT', 'Vermont'),
('WA', 'Washington'),
('WI', 'Wisconsin'),
('WV', 'West Virginia'),
('WY', 'Wyoming');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(20) NOT NULL,
  `family_name` varchar(30) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` char(40) NOT NULL,
  `email` varchar(100) NOT NULL,
  `token` char(32) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `first_name`, `family_name`, `username`, `password`, `email`, `token`) VALUES
(1, 'Arthur', 'Dent', 'hitchhiker', '875939fc9fc673a821319e3f925b270d2786f542', '', NULL),
(3, 'Zaphod', 'Beeblebrox', 'pangalacticgb', '875939fc9fc673a821319e3f925b270d2786f542', '', NULL);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
