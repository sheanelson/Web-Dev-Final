// JavaScript Document

$(function(){
  var stateSelector = $('#state');
  var options = { 
	imageLoading:			'../../images/lightbox/lightbox-ico-loading.gif',		// (string) Path and the name of the loading icon
	imageBtnPrev:			'../../images/lightbox/lightbox-btn-prev.gif',			// (string) Path and the name of the prev button image
	imageBtnNext:			'../../images/lightbox/lightbox-btn-next.gif',			// (string) Path and the name of the next button image
	imageBtnClose:			'../../images/lightbox/lightbox-btn-close.gif',		// (string) Path and the name of the close btn
	imageBlank:				'../../images/lightbox/lightbox-blank.gif',			// (string) Path and the name of a blank image (one pixel)
	fixedNavigation:		false,		// (boolean) Boolean that informs if the navigation (next and prev button) will be fixed or not in the interface.
	containerResizeSpeed:	400,			 // Specify the resize duration of container image. These number are miliseconds. 400 is default.
	overlayBgColor: 		"#cccccc",		// (string) Background color to overlay; inform a hexadecimal value like: #RRGGBB. Where RR, GG, and BB are the hexadecimal values for the red, green, and blue values of the color.
	overlayOpacity:			0.6,		// (integer) Opacity value to overlay; inform: 0.X. Where X are number from 0 to 9
	txtImage:				'Image',				//Default text of image
	txtOf:					'of'
  }
  $('#gallery a').lightBox(options);
  $('#selectState').hide();
  stateSelector.change(function() {
    var selectedState = stateSelector.val();
	var gallery = $('#gallery > ul');
	var places = $('#places');
	places.fadeOut();
	places.html('<h2>Getting places to visit in ' + selectedState + '</h2>');
	$.get('scripts/load_places.php', {state: selectedState}, function(data) {
	  places.html(data).hide();
	  places.fadeIn();
	  document.title = 'Destinations West: ' + selectedState;
	  gallery.fadeOut();
	  $.get('scripts/load_gallery.php', {state: selectedState}, function(data) {
	    gallery.html(data).hide();
	    gallery.fadeIn();
	    $('#gallery a').lightBox(options);
	  });
	});
  });
});