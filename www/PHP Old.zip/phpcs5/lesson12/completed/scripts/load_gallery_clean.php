<?php
require_once('library.php');
require_once('db_definitions_10.php');
if (isset($_GET['state'])) {
  try {
	$pix = getGalleryByState($dbRead, $_GET['state']);
	if ($pix) {
	  // generate the new widget
	  foreach ($pix as $pic) { ?>
        <li> <a href="/cms/image_upload/<?php echo $pic['filename'] ?>" title="<?php echo $pic['name'] . ': ' . $pic['caption']; ?>"><img src="/cms/image_upload/<?php echo $pic['filename'] ?>" width="120" alt="<?php echo $pic['caption']; ?>" /></a> </li>
<?php }
	}
  } catch (Exception $e) {
	echo $e->getMessage();
  }
}