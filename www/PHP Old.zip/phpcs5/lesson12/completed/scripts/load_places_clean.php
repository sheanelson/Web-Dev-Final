<?php
require_once('library.php');
require_once('db_definitions_10.php');
if (isset($_GET['state'])) {
  try {
	$places = getPlacesByState($dbRead, $_GET['state']);
	if ($places) { ?>
    <h2>Places to visit in <?php echo $_GET['state']; ?></h2>
    <?php
	  foreach ($places as $place) { ?>
    <p><strong><?php echo $place['name']; ?>: </strong><?php echo substr($place['description'], 0, strpos($place['description'], '. ')+1); ?> <a href="/places/<?php echo $place['link_name']; ?>">Learn more</a></p>
    <?php }
	}
  } catch (Exception $e) {
	echo $e->getMessage();
  }
}