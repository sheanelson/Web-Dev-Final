<?php
$captionMin = 0;
$captionMax = 150;
$descriptionMin = 10;
$descriptionMax = NULL;
$photofields = 3;
$destination = 'C:/vhosts/phpcs5/cms/image_upload';

function getAllStates($read) {
  $sql = 'SELECT * FROM states ORDER BY state_name';
  return $read->fetchAll($sql);
}

function getAllPlaces($read) {
  $sql = 'SELECT place_id, name FROM places ORDER BY name';
  return $read->fetchAll($sql);
}

function getPlace($read, $place_id) {
  $sql = "SELECT name, places.state_id, state_name, description, link_name
          FROM places
		  INNER JOIN states USING (state_id)
		  WHERE place_id = $place_id";
  return $read->fetchRow($sql);
}

function getPhotoDetails($read, $photo_id) {
  $sql = "SELECT filename, caption FROM photos WHERE photo_id = $photo_id";
  return $read->fetchRow($sql);
}

function validatePlaceName($name, &$errors) {
  $val = new Zend_Validate_Regex('/^[a-z]+[-\'a-z ]+$/i');
  if (!$val->isValid($name)) {
	$errors['name'] = 'Place name is required: no special characters';
  }
}

function validateDescription($description, $val, &$errors) {
  if (!$val->isValid($description)) {
    $errors['description'] = 'Description is required';
  }
}

function validateCaption($caption, $num, $val, &$errors) {
  if (!$val->isValid($caption)) {
    $errors["photo{$num}"] = "Caption for photo $num is too long"; 
  }
}

function checkDuplicatePlacename ($read, $name, &$errors, $place_id = NULL) {
  $sql = $read->quoteInto('SELECT place_id FROM places WHERE name = ?', $name);
  if ($place_id) {
	$sql .= " AND place_id <> $place_id";
  }
  $result = $read->fetchAll($sql);
  if ($result) {
	$errors['name'] = $_POST['name'] . ' is already listed';
  }
}

function checkLinkname($read, $link_name, &$errors, $place_id) {
   $sql = $read->quoteInto("SELECT place_id FROM places WHERE link_name = ? AND place_id <> $place_id", $link_name);
	$result = $read->fetchAll($sql);
	if ($result) {
	  $errors['link_name'] = "$link_name is already listed";
  }
}

function getRelatedPlaces($read, $photo_id) {
  $sql = "SELECT place_id FROM place2photo WHERE photo_id = $photo_id";
  $result = $read->fetchAll($sql);
  $places = array();
  foreach ($result as $row) {
	$places[] = $row['place_id'];
  }
  return $places;
}

function getRelatedPlaceNames($read, $photo_id) {
  $sql = "SELECT name FROM places
          INNER JOIN place2photo USING (place_id)
		  WHERE photo_id = $photo_id ORDER BY name";
  $result = $read->fetchAll($sql);
  $places = array();
  foreach ($result as $row) {
	$places[] = $row['name'];
  }
  return $places;
}

function getRelatedPhotos($read, $place_id) {
  $sql = "SELECT photos.photo_id, filename, caption
          FROM photos
		  INNER JOIN place2photo USING (photo_id)
		  WHERE place_id = $place_id";
  return $read->fetchAll($sql);
}

function checkId ($id, $location) {
  if (isset($_GET[$id]) && is_numeric($_GET[$id])) {
    return intval($_GET[$id]);
  } elseif (isset($_POST[$id]) && is_numeric($_POST[$id])) {
    return intval($_POST[$id]);
  } else {
    header("Location: $location");
    exit;
  }
}

function getRegisteredStates($read) {
  $sql = 'SELECT DISTINCT state_name FROM states
          INNER JOIN places USING (state_id)
		  ORDER BY state_name';
  return $read->fetchCol($sql);
}

function getGalleryByState($read, $state_name) {
  $sql = $read->quoteInto('SELECT name, filename, caption
          FROM places
          INNER JOIN states USING (state_id)
		  INNER JOIN place2photo USING (place_id)
		  INNER JOIN photos USING (photo_id)
		  WHERE state_name = ?
		  ORDER BY name', $state_name);
  return $read->fetchAll($sql);
}

function getPlacesByState($read, $state_name) {
  $sql = $read->quoteInto('SELECT name, description, link_name
          FROM places
		  INNER JOIN states USING (state_id)
		  WHERE state_name = ?
		  ORDER BY name', $state_name);
  return $read->fetchAll($sql);
}