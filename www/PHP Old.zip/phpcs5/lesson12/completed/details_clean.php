<?php
require_once('scripts/library.php');
require_once('scripts/db_definitions_10.php');
try {
  if (isset($_GET['place'])) {
	$place = getPlaceByLinkname($dbRead, $_GET['place']);
	if ($place) {
	  $pix = getRelatedPhotos($dbRead, $place['place_id']);
	}
  } else {
	$place = NULL;
  }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Photo Gallery</title>
<link href="/styles/destinations.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div id="wrapper"> <img src="/images/destinations.jpg" width="960" height="232" alt="Destinations West" />
  <div id="maincontent">
  <?php if (!$place) { ?>
    <h2>No record found</h2>
  <?php } else { ?>
    <h2><?php echo $place['name'] . ', ' . $place['state_name']; ?></h2>
  <?php 
    $paras = splitParas($place['description']);
	$imagedir = '/cms/image_upload/';
    for ($i = 0, $j = 0, $num_paras = count($paras); $i < $num_paras; $i++) {
	  echo '<p>';
	  if (isset($pix[$j]) && !($i % 2)) { 
	    $image = $imagedir . $pix[$j]['filename'];
	    $imagesize = getimagesize($_SERVER['DOCUMENT_ROOT'] . $image);
	  ?>
      <span class="<?php echo ($j % 2) ? 'floatleft' : 'floatright'; ?>" style="width:<?php echo $imagesize[0] ?>px"><img src="<?php echo $image; ?>" alt="<?php echo $pix[$j]['caption']; ?>" <?php echo $imagesize[3] ?> /> <?php echo $pix[$j++]['caption']; ?></span>
      <?php
	  }
	  echo $paras[$i];
	  echo '</p>';
	}
  } ?>
  <p id="updated">Information correct as of <?php echo $place['updated']; ?></p>
  <p><a href="/states/<?php echo $place['state_name']; ?>">Back to places in <?php echo $place['state_name']; ?></a></p>
  </div>
</div>
</body>
</html>
<?php
} catch (Exception $e) {
  $e->getMessage();
}