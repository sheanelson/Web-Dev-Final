<?php
require_once('scripts/library.php');
require_once('scripts/db_definitions.php');
try {
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Destinations West: </title>
<link href="../../styles/destinations.css" rel="stylesheet" type="text/css" />
<script src="../../scripts/jquery.js" type="text/javascript"></script>
<script src="../../scripts/lightbox.js" type="text/javascript"></script>
<link href="../../css/lightbox.css" rel="stylesheet" type="text/css" />
<link href="../../css/sample_lightbox_layout.css" rel="stylesheet" type="text/css" />
<style type="text/css">
/* BeginOAWidget_Instance_2127022: #gallery */

		.lbGallery { 
			/*gallery container settings*/
			background-color: #ffffff;
			padding-left: 0px;  
			padding-top: 0px;  
			padding-right: 0px;  
			padding-bottom: 0px;  
			width: 240px;
			height: auto;
			text-align:center;
		}
		.lbGallery ul { list-style: none; margin:0;padding:0; }
		.lbGallery ul li { display: inline;margin:0;padding:0; }
		.lbGallery ul li a{text-decoration:none;}
			
		.lbGallery ul li a img {
			/*border color, width and margin for the images*/
			border-color: #ffffff;
			border-left-width: 10px;
			border-top-width: 10px;
			border-right-width: 10px;
			border-bottom-width: 10px;
			margin-left:0px;
			margin-right:0px;
			margin-top:0px;
			margin-bottom:0px:
			}
			
		.lbGallery ul li a:hover img {	
			/*background color on hover*/
			border-color: #79b4d9;
			border-left-width: 10px;
			border-top-width: 10px;
			border-right-width: 10px;
			border-bottom-width: 10px;
		}
			
		#lightbox-container-image-box {
			border-top: 6px double #000000;
			border-right: 6px double #000000;
			border-bottom: 6px double #000000;
			border-left: 6px double #000000;
			}
			
		#lightbox-container-image-data-box { 
			border-top: 0px;
			border-right: 6px double #000000;
			border-bottom: 6px double #000000;
			border-left: 6px double #000000;
			}
/* EndOAWidget_Instance_2127022 */
</style>
<script type="text/xml">
<!--
<oa:widgets>
  <oa:widget wid="2127022" binding="#gallery" />
</oa:widgets>
-->
</script>
</head>

<body>
<div id="wrapper">
  <img src="../../images/destinations.jpg" width="960" height="232" alt="Destinations West" />
  <form id="form1" name="form1" method="get" action="">
    <label for="state">Select a state:</label>
    <select name="state" id="state">
    </select>
    <input type="submit" name="selectState" id="selectState" value="Go" />
  </form>
  <div id="gallery" class="lbGallery">
    <ul>
      <li> <a href="/images/lightboxdemo1.jpg" title=""><img src="/images/lightboxdemo_thumb1.jpg" width="72" height="72" alt="Flower" /></a> </li>
      <li> <a href="/images/lightboxdemo2.jpg" title=""><img src="/images/lightboxdemo_thumb2.jpg" width="72" height="72" alt="Tree" /></a> </li>
      <li> <a href="/images/lightboxdemo3.jpg" title=""><img src="/images/lightboxdemo_thumb3.jpg" width="72" height="72" alt="" /></a> </li>
      <li> <a href="/images/lightboxdemo4.jpg" title=""><img src="/images/lightboxdemo_thumb4.jpg" width="72" height="72" alt="" /></a> </li>
      <li> <a href="/images/lightboxdemo5.jpg" title=""><img src="/images/lightboxdemo_thumb5.jpg" width="72" height="72" alt="" /></a> </li>
    </ul>
  </div>
  <script type="text/javascript">
// BeginOAWidget_Instance_2127022: #gallery

		$(function(){
			$('#gallery a').lightBox({ 
				imageLoading:			'/images/lightbox/lightbox-ico-loading.gif',		// (string) Path and the name of the loading icon
				imageBtnPrev:			'/images/lightbox/lightbox-btn-prev.gif',			// (string) Path and the name of the prev button image
				imageBtnNext:			'/images/lightbox/lightbox-btn-next.gif',			// (string) Path and the name of the next button image
				imageBtnClose:			'/images/lightbox/lightbox-btn-close.gif',		// (string) Path and the name of the close btn
				imageBlank:				'/images/lightbox/lightbox-blank.gif',			// (string) Path and the name of a blank image (one pixel)
				fixedNavigation:		false,		// (boolean) Boolean that informs if the navigation (next and prev button) will be fixed or not in the interface.
				containerResizeSpeed:	400,			 // Specify the resize duration of container image. These number are miliseconds. 400 is default.
				overlayBgColor: 		"#cccccc",		// (string) Background color to overlay; inform a hexadecimal value like: #RRGGBB. Where RR, GG, and BB are the hexadecimal values for the red, green, and blue values of the color.
				overlayOpacity:			0.6,		// (integer) Opacity value to overlay; inform: 0.X. Where X are number from 0 to 9
				txtImage:				'Image',				//Default text of image
				txtOf:					'of'
			});
		});
		
// EndOAWidget_Instance_2127022
  </script>
<div id="places">
    <h2>Places to visit in </h2>
  </div>
</div>
</body>
</html>
<?php 
} catch (Exception $e) {
  echo $e->getMessage();
}
?>