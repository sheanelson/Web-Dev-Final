<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Delete user record</title>
<link href="../../styles/users.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Confirm Deletion</h1>
<p>You are about to delete the following record. This cannot be undone.</p>
<p>Name:</p>
<p>Username:</p>
<form id="form1" name="form1" method="post" action="">
  <input type="submit" name="confirm" id="confirm" value="Delete" />
  <input type="submit" name="cancel" id="cancel" value="Cancel" />
</form>
</body>
</html>