<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Update user details</title>
<link href="../../styles/users.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Update User Record</h1>
<form id="form1" name="form1" method="post" action="">
  <fieldset>
    <legend>Leave password blank if no change</legend>
    <p>
      <label for="first_name">First name:</label>
      <input type="text" name="first_name" id="first_name" />
    </p>
    <p>
      <label for="surname">Family name:</label>
      <input type="text" name="surname" id="surname" />
    </p>
    <p>
      <label for="username">Username:</label>
      <input type="text" name="username" id="username" />
    </p>
    <p>
      <label for="password">Password:</label>
      <input type="password" name="password" id="password" />
    </p>
    <p>
      <label for="conf_password">Confirm password:</label>
      <input type="password" name="conf_password" id="conf_password" />
    </p>
    <p>
      <input type="submit" name="add_user" id="add_user" value="Update" />
    </p>
  </fieldset>
</form>
</body>
</html>