<?php require_once('Connections/cs5read.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$maxRows_getUsers = 10;
$pageNum_getUsers = 0;
if (isset($_GET['pageNum_getUsers'])) {
  $pageNum_getUsers = $_GET['pageNum_getUsers'];
}
$startRow_getUsers = $pageNum_getUsers * $maxRows_getUsers;

mysql_select_db($database_cs5read, $cs5read);
$query_getUsers = "SELECT user_id, first_name, family_name, username FROM users ORDER BY family_name ASC";
$query_limit_getUsers = sprintf("%s LIMIT %d, %d", $query_getUsers, $startRow_getUsers, $maxRows_getUsers);
$getUsers = mysql_query($query_limit_getUsers, $cs5read) or die(mysql_error());
$row_getUsers = mysql_fetch_assoc($getUsers);

if (isset($_GET['totalRows_getUsers'])) {
  $totalRows_getUsers = $_GET['totalRows_getUsers'];
} else {
  $all_getUsers = mysql_query($query_getUsers);
  $totalRows_getUsers = mysql_num_rows($all_getUsers);
}
$totalPages_getUsers = ceil($totalRows_getUsers/$maxRows_getUsers)-1;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Registered Users</title>
<link href="../../styles/users.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Registered Users</h1>
<table>
  <tr>
    <th scope="col">Real name</th>
    <th scope="col">Username</th>
    <th scope="col">&nbsp;</th>
    <th scope="col">&nbsp;</th>
  </tr>
  <?php do { ?>
    <tr>
      <td><?php echo $row_getUsers['first_name']; ?> <?php echo $row_getUsers['family_name']; ?></td>
      <td><?php echo $row_getUsers['username']; ?></td>
      <td>EDIT</td>
      <td>DELETE</td>
    </tr>
    <?php } while ($row_getUsers = mysql_fetch_assoc($getUsers)); ?>
</table>
</body>
</html>
<?php
mysql_free_result($getUsers);
?>
