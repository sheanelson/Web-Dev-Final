<?php require_once('Connections/cs5write.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_getUser = "-1";
if (isset($_GET['user_id'])) {
  $colname_getUser = $_GET['user_id'];
}
mysql_select_db($database_cs5write, $cs5write);
$query_getUser = sprintf("SELECT user_id, first_name, family_name, username FROM users WHERE user_id = %s", GetSQLValueString($colname_getUser, "int"));
$getUser = mysql_query($query_getUser, $cs5write) or die(mysql_error());
$row_getUser = mysql_fetch_assoc($getUser);
$totalRows_getUser = mysql_num_rows($getUser);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Update user details</title>
<link href="../../styles/users.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Update User Record</h1>
<form id="form1" name="form1" method="post" action="">
  <fieldset>
    <legend>Leave password blank if no change</legend>
    <p>
      <label for="first_name">First name:</label>
      <input name="first_name" type="text" id="first_name" value="<?php echo $row_getUser['first_name']; ?>" />
    </p>
    <p>
      <label for="surname">Family name:</label>
      <input name="surname" type="text" id="surname" value="<?php echo $row_getUser['family_name']; ?>" />
    </p>
    <p>
      <label for="username">Username:</label>
      <input name="username" type="text" id="username" value="<?php echo $row_getUser['username']; ?>" />
    </p>
    <p>
      <label for="password">Password:</label>
      <input type="password" name="password" id="password" />
    </p>
    <p>
      <label for="conf_password">Confirm password:</label>
      <input type="password" name="conf_password" id="conf_password" />
    </p>
    <p>
      <input type="submit" name="add_user" id="add_user" value="Update" />
    </p>
  </fieldset>
</form>
</body>
</html>
<?php
mysql_free_result($getUser);
?>
