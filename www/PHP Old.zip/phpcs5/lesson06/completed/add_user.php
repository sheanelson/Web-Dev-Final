<?php require_once('Connections/cs5write.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO user (first_name, family_name, username, password) VALUES (%s, %s, %s, %s)",
                       GetSQLValueString($_POST['first_name'], "text"),
                       GetSQLValueString($_POST['surname'], "text"),
                       GetSQLValueString($_POST['username'], "text"),
                       GetSQLValueString($_POST['password'], "text"));

  mysql_select_db($database_cs5write, $cs5write);
  $Result1 = mysql_query($insertSQL, $cs5write) or die(mysql_error());

  $insertGoTo = "login.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Add new user</title>
<link href="../../styles/users.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Sign Up Now</h1>
<form id="form1" name="form1" method="POST" action="<?php echo $editFormAction; ?>">
  <fieldset>
    <legend>Just a few details and you&rsquo;re in</legend>
    <p>
      <label for="first_name">First name:</label>
      <input type="text" name="first_name" id="first_name" />
    </p>
    <p>
      <label for="surname">Family name:</label>
      <input type="text" name="surname" id="surname" />
    </p>
    <p>
      <label for="username">Username:</label>
      <input type="text" name="username" id="username" />
    </p>
    <p>
      <label for="password">Password:</label>
      <input type="password" name="password" id="password" />
    </p>
    <p>
      <label for="conf_password">Confirm password:</label>
      <input type="password" name="conf_password" id="conf_password" />
    </p>
    <p>
      <input type="submit" name="add_user" id="add_user" value="Sign me up!" />
    </p>
  </fieldset>
  <input type="hidden" name="MM_insert" value="form1" />
</form>
</body>
</html>