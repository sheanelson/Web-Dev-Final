<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_cs5write = "localhost";
$database_cs5write = "phpcs5";
$username_cs5write = "cs5write";
$password_cs5write = "Bow!e#CS5";
$cs5write = mysql_pconnect($hostname_cs5write, $username_cs5write, $password_cs5write) or trigger_error(mysql_error(),E_USER_ERROR); 
?>