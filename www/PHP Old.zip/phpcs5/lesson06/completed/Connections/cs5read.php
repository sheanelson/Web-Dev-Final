<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_cs5read = "localhost";
$database_cs5read = "phpcs5";
$username_cs5read = "cs5read";
$password_cs5read = "5T@rmaN";
$cs5read = mysql_pconnect($hostname_cs5read, $username_cs5read, $password_cs5read) or trigger_error(mysql_error(),E_USER_ERROR); 
?>