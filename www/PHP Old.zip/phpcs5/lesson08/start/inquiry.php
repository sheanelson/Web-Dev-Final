<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Contact Us</title>
<link href="../../styles/users_wider.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Travel Inquiry</h1>
<form id="form1" name="form1" method="post" action="">
  <p>
    <label for="name">Your name:</label>
    <input type="text" name="name" id="name" />
  <span>
  <?php if ($_POST && isset($errors['name'])) {
    echo $errors['name'];
 } ?>
  </span></p>
  <p>
    <label for="email">Email address:</label>
    <input type="text" name="email" id="email" />
  <span>
  <?php if ($_POST && isset($errors['email'])) {
    echo $errors['email'];
 } ?>
  </span></p>
  <p><span class="cb_rad_description">Where you want to go:</span>
    <input name="destinations" type="checkbox" id="destinations_coast" value="coast" />
    <label for="destinations_coast" class="nofloat">Coast</label>
  </p>
  <p>
    <input type="checkbox" name="destinations" id="destinations_city" value="city" />
    <label for="destinations_city" class="nofloat">City</label>
  </p>
  <p>
    <input type="checkbox" name="destinations" id="destinations_natpark" value="national parks" />
    <label for="destinations_natpark" class="nofloat">National parks</label>
  </p>
  <p><span class="cb_rad_description">Traveling with dogs?</span>
      <input name="dogs" type="radio" id="dogs_no" value="n" />
    <label for="dogs_no" class="nofloat">No</label>
      <input type="radio" name="dogs" value="y" id="dogs_yes" />
     <label for="dogs_yes" class="nofloat"> Yes</label>
  </p>
  <p>
    <label for="howmany">How many traveling?</label>
    <select name="howmany" id="howmany">
      <option value="0" selected="selected">-- Select one --</option>
      <option value="1">One adult</option>
      <option value="2">Two adults</option>
      <option value="3">Adults and children</option>
    </select>
  </p>
  <p>
    <label for="interests">Special interests:</label>
    <select name="interests" size="4" multiple="multiple" id="interests">
      <option value="cycling">Cycling</option>
      <option value="gourmet">Gourmet dining</option>
      <option value="surfing">Surfing</option>
      <option value="walking">Walking</option>
    </select>
  </p>
  <p>
    <label for="comments">Comments:</label>
    <textarea name="comments" id="comments" cols="45" rows="5"></textarea>
    <span>
    <?php if ($_POST && isset($errors['comments'])) {
    echo $errors['comments'];
 } ?>
    </span><br />
  </p>
  <p>
    <input type="submit" name="send" id="send" value="Send Inquiry" />
  </p>
</form>
</body>
</html>