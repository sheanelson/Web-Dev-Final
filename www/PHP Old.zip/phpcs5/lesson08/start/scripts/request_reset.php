<?php
$errors = FALSE;
$result = FALSE;
if ($_POST) {
  require_once('library.php');
  require_once('mail_connector.php');
  try {
	
  } catch (Exception $e) {
	echo $e->getMessage();
  }
}