<?php
require_once('library.php');
$errors = array();
try {
  if (isset($_POST['send'])) {
	// validate the user input
	$val = new Zend_Validate_Alnum(TRUE);
	if (!$val->isValid($_POST['name'])) {
	  $errors['name'] = 'Name is required';
	}
	$val = new Zend_Validate_EmailAddress();
	if (!$val->isValid($_POST['email'])) {
	  $errors['email'] = 'Email address is required';
	}
	$val = new Zend_Validate_StringLength(10);
	if (!$val->isValid($_POST['comments'])) {
	  $errors['comments'] = 'Required';
	}
	if (!$errors) {
	 // create and send the email
	}
  }
} catch (Exception $e) {
  echo $e->getMessage();
}
?>