<?php
$mailhost = 'smtp.example.com';
$mailconfig = array('auth'     => 'login',
                    'username' => 'me@example.com',
					'password' => 'topsecret');
$transport = new Zend_Mail_Transport_Smtp($mailhost, $mailconfig);
Zend_Mail::setDefaultTransport($transport);