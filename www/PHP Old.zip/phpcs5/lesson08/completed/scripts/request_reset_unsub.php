<?php
$errors = FALSE;
$result = FALSE;
if ($_POST) {
  require_once('library.php');
  require_once('mail_connector.php');
  try {
	$val = new Zend_Validate_EmailAddress();
	if (!$val->isValid($_POST['email'])) {
	  $errors = TRUE;
	}
	if (!$errors) {
	  $sql = $dbRead->quoteInto('SELECT user_id, first_name, family_name, email FROM users WHERE email = ?', $_POST['email']);
	  $result = $dbRead->fetchRow($sql);
	  if (!$result) {
		$errors = TRUE;
	  } else {
        // update database and send mail
		$token = md5(uniqid(mt_rand(), TRUE));
		$data = array('token' => $token);
		$where = $dbWrite->quoteInto('email = ?', $_POST['email']);
		$dbWrite->update('users', $data, "user_id = {$result['user_id']}");	
	  }
	  $mail = new Zend_Mail('UTF-8');
	  $mail->addTo($result['email'], "{$result['first_name']} {$result['family_name']}");
	  $mail->setFrom('webmaster@example.com', 'DW CS5 with PHP');
	  if (isset($_POST['unsub'])) {
		$mail->setSubject('Instructions for unsubscribing');
		$link = "http://phpcs5/lesson08/completed/confirm_unsub.php?id={$result['user_id']}&token=$token";
		$message = "Use the following link to unsubscribe. $link";
	  } else {
		$mail->setSubject('Instructions for resetting your password');
		$link = "http://phpcs5/lesson08/workfiles/reset.php?id={$result['user_id']}&token=$token";
		$message = "Use the following link to reset your password. This link can be used once only. $link";
	  }
	  $mail->setBodyText($message, 'UTF-8');
	  $mail->send();
	}
  } catch (Exception $e) {
	echo $e->getMessage();
  }
}