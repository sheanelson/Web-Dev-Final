<?php
$to = 'david@example.com';
$subject = 'PHP mail test';
$message = 'This is a test of the PHP mail() function.';
$headers = "From: webmaster@example.com\r\n";
$headers .= 'Cc: another@example.com';
$success = mail($to, $subject, $message, $headers);
if ($success) {
  echo 'Mail sent';
} else {
  echo 'Problem sending mail';
}