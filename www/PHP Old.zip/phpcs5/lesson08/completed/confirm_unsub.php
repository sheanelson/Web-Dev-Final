<?php
require_once('scripts/reset_password_unsub.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Reset Password</title>
<link href="../../styles/users_wider.css" rel="stylesheet" type="text/css" />
</head>

<body>
<?php if (isset($_POST['cancel'])) { ?>
<h1>Cancelled</h1>
<p>Your request to be removed from our records has been cancelled.</p>
<?php } elseif ($success) { ?>
<h1>Record Deleted</h1>
<p>Your details have been removed from our records. If you wish to resubscribe, please register again.</p>
<?php } elseif ($_SESSION['nomatch']) { ?>
<h1>Error</h1>
<p>Sorry, there was an error. Make sure you used the complete URL in the email you received. The URL can be used to change your password only once. If necessary, <a href="forgotten.php">submit another request</a>.</p>
<?php } else { ?>
<h1>Confirm Unsubscription</h1>
<form id="form1" name="form1" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
  <p>Please confirm that you want your details removed from our records</p>
  <p>
    <input type="submit" name="confirm" id="confirm" value="Confirm" />
    <input type="submit" name="cancel" id="cancel" value="Cancel" />
  </p>
</form>
<?php } ?>
</body>
</html>