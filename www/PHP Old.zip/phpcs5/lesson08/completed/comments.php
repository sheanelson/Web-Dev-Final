<?php
require_once('scripts/process_comments.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Contact Us</title>
<link href="../../styles/users_wider.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Get In Touch</h1>
<form id="form1" name="form1" method="post" action="">
  <?php if (isset($success) && !$errors) { ?>
  <p>Thank you. Your comments have been sent.</p>
  <?php } elseif (isset($success) && $errors) { ?>
  <p>Sorry, there was a problem. Please try later.</p>
  <?php } ?>
  <p>All fields are required</p>
  <p>
    <label for="name">Your name:</label>
    <input value="<?php if ($_POST && $errors) {
  echo htmlentities($_POST['name'], ENT_COMPAT, 'UTF-8');
}?>" type="text" name="name" id="name" />
    <span>
    <?php if ($_POST && isset($errors['name'])) {
    echo $errors['name'];
 } ?>
    </span></p>
  <p>
    <label for="email">Email address:</label>
    <input value="<?php if ($_POST && $errors) {
  echo htmlentities($_POST['email'], ENT_COMPAT, 'UTF-8');
}?>" type="text" name="email" id="email" />
  <span>
  <?php if ($_POST && isset($errors['email'])) {
    echo $errors['email'];
 } ?>
  </span></p>
  <p>
    <label for="comments">Comments:</label>
    <textarea name="comments" id="comments" cols="45" rows="5"><?php if ($_POST && $errors) {echo htmlentities($_POST['comments'], ENT_COMPAT, 'UTF-8');}?></textarea>
  <span>
  <?php if ($_POST && isset($errors['comments'])) {
    echo $errors['comments'];
 } ?>
  </span></p>
  <?php if (isset($errors['recaptcha'])) { 
    echo "<p><span>{$errors['recaptcha']}</span></p>"; 
  }
  echo $recaptcha->getHtml(); ?>
  <p>
    <input type="submit" name="send" id="send" value="Send Comments" />
  </p>
</form>
</body>
</html>