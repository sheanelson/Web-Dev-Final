<?php
require_once('scripts/request_reset_unsub.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Unsubscribe</title>
<link href="../../styles/users.css" rel="stylesheet" type="text/css" />
</head>

<body>
<?php if ($result) {?>
<h1>Request Received</h1>
<p>An email has been sent to your registered address requesting confirmation.</p>
<?php } else { ?>
<h1>Unsubscribe</h1>
<p>If you would like to unsubscribe, please enter the email address you used when registering.</p>
<form id="form1" name="form1" method="post" action="">
  <p>
    <label for="email">Email address:</label>
    <input type="text" name="email" id="email" />
  </p>
  <p>
    <input type="submit" name="unsub" id="unsub" value="Unsubscribe" />
  </p>
</form>
<?php  if ($errors) { ?>
	<p class="warning">Sorry, there is no record of that address.</p>
<?php }
}?>
</body>
</html>