<?php
require_once('scripts/user_registration.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Add new user</title>
<link href="../../styles/users_wider.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Sign Up Now</h1>
<form id="form1" name="form1" method="post" action="">
  <fieldset>
    <legend>Just a few details and you&rsquo;re in</legend>
    <p>All fields are required</p>
    <p>
      <label for="first_name">First name:</label>
      <input type="text" name="first_name" id="first_name"
      value="<?php if ($_POST && $errors) {
		echo htmlentities($_POST['first_name'], ENT_COMPAT, 'UTF-8');
	  }?>"
       />
      <span>
      <?php
	  if ($_POST && isset($errors['first_name'])) {
		  echo $errors['first_name'];
	  }
	  ?>
      </span>
    </p>
    <p>
      <label for="surname">Family name:</label>
      <input type="text" name="surname" id="surname" />
    </p>
    <p>
      <label for="username">Username (6&#8211;15 characters):</label>
      <input type="text" name="username" id="username" />
    </p>
    <p>
      <label for="password">Password (8&#8211;15 characters):</label>
      <input type="password" name="password" id="password" />
    </p>
    <p>
      <label for="conf_password">Confirm password:</label>
      <input type="password" name="conf_password" id="conf_password" />
    </p>
    <p>
      <label for="email">Email address:</label>
      <input type="text" name="email" id="email" />
    </p>
    <p>
      <input type="submit" name="add_user" id="add_user" value="Sign me up!" />
    </p>
  </fieldset>
</form>
</body>
</html>