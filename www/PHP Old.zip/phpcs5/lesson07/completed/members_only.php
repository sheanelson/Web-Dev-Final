<?php
require_once('scripts/restrict_access.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Members Only</title>
<link href="../../styles/users.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Welcome to the Clubhouse</h1>
<p>Hi, <?php echo "$identity->first_name $identity->family_name"; ?>. You're in! This is where the cool guys and gals hang out.</p>
<p><a href="login.php?logout">Log out.</a></p>
</body>
</html>