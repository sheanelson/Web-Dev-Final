<?php
$failed = FALSE;
if ($_POST) {
  if (empty($_POST['username']) || empty($_POST['password'])) {
	$failed = TRUE;
  } else {
	require_once('library.php');
	// check the user's credentials
	try {
	  $auth = Zend_Auth::getInstance();
	  $adapter = new Zend_Auth_Adapter_DbTable($dbRead, 'users', 'username', 'password', 'sha1(?)');
	  $adapter->setIdentity($_POST['username']);
	  $adapter->setCredential($_POST['password']);
	  $result = $auth->authenticate($adapter);
	  if ($result->isValid()) {
		$storage = $auth->getStorage();
		$storage->write($adapter->getResultRowObject(array(
		  'username', 'first_name', 'family_name')));
		header('Location: members_only.php');
		exit;
	  } else {
		$failed = TRUE;
	  }
	} catch (Exception $e) {
	  echo $e->getMessage();
	}
  }
}
if (isset($_GET['logout'])) {
  require_once('library.php');
  try {
	$auth = Zend_Auth::getInstance();
	$auth->clearIdentity();
  } catch (Exception $e) {
	echo $e->getMessage();
  }
}