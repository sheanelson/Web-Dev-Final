<?php
$errors = array();
if ($_POST) {
  // run the validation script
  require_once('library.php');
  try {
	// main script goes here
	$val = new Zend_Validate_Regex('/^[a-z]+[-\'a-z ]+$/i');
	if (!$val->isValid($_POST['first_name'])) {
	  $errors['first_name'] = 'Required field, no numbers';
	}
	if (!$val->isValid($_POST['surname'])) {
	  $errors['surname'] = 'Required field, no numbers';
	}
	$val = new Zend_Validate();
	$length = new Zend_Validate_StringLength(6,15);
	$val->addValidator($length);
	$val->addValidator(new Zend_Validate_Alnum());
	if (!$val->isValid($_POST['username'])) {
	  $errors['username'] = 'Use 6-15 letters or numbers only';
	} else {
	  $sql = $dbRead->quoteInto('SELECT user_id FROM users WHERE username = ?', $_POST['username']);
      $result = $dbRead->fetchAll($sql);
	  if ($result) {
		$errors['username'] = $_POST['username'] . ' is already in use';
	  }
	}
	$length->setMin(8);
	$val = new Zend_Validate();
	$val->addValidator($length);
	$val->addValidator(new Zend_Validate_Alnum());
	if (!$val->isValid($_POST['password'])) {
	  $errors['password'] = 'Use 8-15 letters or numbers only';
	}
	$val = new Zend_Validate_Identical($_POST['password']);
	if (!$val->isValid($_POST['conf_password'])) {
	  $errors['conf_password'] = "Passwords don't match";
	}
	$val = new Zend_Validate_EmailAddress();
	if (!$val->isValid($_POST['email'])) {
	  $errors['email'] = 'Use a valid email address';
	}
	if (!$errors) {
	  // insert the details in the database
	  $data = array('first_name'  => $_POST['first_name'],
	                'family_name' => $_POST['surname'],
					'username'    => $_POST['username'],
					'password'    => sha1($_POST['password']));
       $dbWrite->insert('users', $data);
	   header('Location: login.php');
	}
  } catch (Exception $e) {
	echo $e->getMessage();
  }
}