<?php
$errors = array();
if ($_POST) {
  // run the validation script
  require_once('library.php');
  try {
	// main script goes here
	$val = new Zend_Validate_Regex('/^[a-z]+[-\'a-z ]+$/i');
	if (!$val->isValid($_POST['first_name'])) {
	  $errors['first_name'] = 'Required field, no numbers';
	}
  } catch (Exception $e) {
	echo $e->getMessage();
  }
}