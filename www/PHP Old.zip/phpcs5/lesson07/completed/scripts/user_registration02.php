<?php
$errors = array();
if ($_POST) {
  // run the validation script
  require_once('library.php');
  try {
	// main script goes here
	$val = new Zend_Validate_Regex('/^[a-z]+[-\'a-z ]+$/i');
	if (!$val->isValid($_POST['first_name'])) {
	  $errors['first_name'] = 'Required field, no numbers';
	}
	if (!$val->isValid($_POST['surname'])) {
	  $errors['surname'] = 'Required field, no numbers';
	}
	$val = new Zend_Validate();
	$length = new Zend_Validate_StringLength(6,15);
	$val->addValidator($length);
	$val->addValidator(new Zend_Validate_Alnum());
	if (!$val->isValid($_POST['username'])) {
	  $errors['username'] = 'Use 6-15 letters or numbers only';
	}
	$length->setMin(8);
	$val = new Zend_Validate();
	$val->addValidator($length);
	$val->addValidator(new Zend_Validate_Alnum());
	if (!$val->isValid($_POST['password'])) {
	  $errors['password'] = 'Use 8-15 letters or numbers only';
	}
	$val = new Zend_Validate_Identical($_POST['password']);
	if (!$val->isValid($_POST['conf_password'])) {
	  $errors['conf_password'] = "Passwords don't match";
	}
	$val = new Zend_Validate_EmailAddress();
	if (!$val->isValid($_POST['email'])) {
	  $errors['email'] = 'Use a valid email address';
	}
  } catch (Exception $e) {
	echo $e->getMessage();
  }
}