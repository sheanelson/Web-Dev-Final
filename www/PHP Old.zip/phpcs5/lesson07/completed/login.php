<?php
require_once('scripts/user_authentication.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>User login</title>
<link href="../../styles/users.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Members Only</h1>
<?php if ($failed) { ?>
<p class="warning">Login failed. Please check username and password.</p>
<?php } ?>
<form id="form1" name="form1" method="POST">
  <p>
    <label for="username">Username:</label>
    <input type="text" name="username" id="username" />
  </p>
  <p>
    <label for="password">Password:</label>
    <input type="password" name="password" id="password" />
  </p>
  <p>
    <input type="submit" name="signin" id="signin" value="Sign in" />
  </p>
</form>
</body>
</html>