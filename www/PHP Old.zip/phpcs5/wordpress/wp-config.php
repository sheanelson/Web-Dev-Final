<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wordpress');

/** MySQL database username */
define('DB_USER', 'wpuser');

/** MySQL database password */
define('DB_PASSWORD', 'redfox');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '-+unn69*ow+a#TY+aLrd;S1W-7Rl*o|d}OWydpjM)bq8+}m%/XmH1noFqeZVXoW4');
define('SECURE_AUTH_KEY',  '@DD;y4~G;;[l,f7I!CDP_:&H_@oU/95c.bXPYn1o*JM;AFY|6mzJG6+VZZigX1Kb');
define('LOGGED_IN_KEY',    'qZw}9<vR+DXRY|QKO=m6e,3*,-2+pzrH>};T&-D8?1v#r/j/65>n|/Is0(.~1MH+');
define('NONCE_KEY',        'SUl+k43;X-}bJm|8{/rbv1-_<O}mFxd;x[(|^o[-!Gs<uMT?#U[P<4-.=+P01o~W');
define('AUTH_SALT',        'i@r2omKpK3CX$Y,^hV4Lie&za8/)lGnPMx|w/IYgi+UiA5Tm!B.T|#)D@d)Df@L,');
define('SECURE_AUTH_SALT', 'TT< ,e8CeflE[t&#t9Sc(el+@|xB6|Wc-4MZ^2Hq5mA+bOeeAmOiCTCuMpD3RK]D');
define('LOGGED_IN_SALT',   'o0ZA|zdS>+-027VYgfXhdq>7|L6V<1rLJ+z`Y6^,?f:^{:h,d->0_mX2VAR^6AvY');
define('NONCE_SALT',       'U^yTH[<Ut8H|uLN4>sb!$?^hU#[p_-}K+|/#w.W#~c#hNj|b3WIi^*uuIi`egj1?');


/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * WordPress Localized Language, defaults to English.
 *
 * Change this to localize WordPress. A corresponding MO file for the chosen
 * language must be installed to wp-content/languages. For example, install
 * de_DE.mo to wp-content/languages and set WPLANG to 'de_DE' to enable German
 * language support.
 */
define('WPLANG', '');

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
