<?php
require_once('scripts/process_upload.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>File Upload Form</title>
</head>

<body>
<?php
if (isset($messages)) {
  echo '<ul>';
  foreach ($messages as $item) {
	echo "<li>$item</li>";
  }
  echo '</ul>';
}
?>
<form action="" method="post" enctype="multipart/form-data" name="form1" id="form1">
  <p>
    <input name="MAX_FILE_SIZE" type="hidden" id="MAX_FILE_SIZE" value="51200" />
    <label for="upload_file">File to upload:</label>
    <input type="file" name="upload_file" id="upload_file" />
  </p>
  <p><strong>Overwrite existing file?</strong></p>
  <p>
    <label>
      <input type="radio" name="overwrite" value="y" id="overwrite_0" />
      Yes</label>
    <br />
    <label>
      <input name="overwrite" type="radio" id="overwrite_1" value="n" checked="checked" />
      No</label>
  </p>
  <p>
    <input type="submit" name="upload" id="upload" value="Upload File" />
  </p>
</form>
</body>
</html>