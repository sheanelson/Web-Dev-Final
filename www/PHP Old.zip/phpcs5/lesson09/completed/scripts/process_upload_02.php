<?php
if (isset($_POST['upload'])) {
  require_once('library.php');
  try {
	$destination = 'C:/upload_test';
	$uploader = new Zend_File_Transfer_Adapter_Http();
	$uploader->setDestination($destination);
	$uploader->addValidator('Size', FALSE, '50kB');
	$uploader->addValidator('MimeType', FALSE, 'image');
	$uploader->addValidator('ImageSize', FALSE, array('minheight' => 50, 'minwidth' => 100));
	$uploader->addValidator('NotExists', FALSE, $destination);
	$success = $uploader->receive();
	if (!$success) {
	  $messages = $uploader->getMessages();
	} else {
	  $filename = $uploader->getFileName(NULL, FALSE);
	  $messages[] = "$filename uploaded successfully";
	}
  } catch (Exception $e) {
	echo $e->getMessage();
  }
}