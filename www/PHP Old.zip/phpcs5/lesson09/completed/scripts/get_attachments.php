<?php
session_start();
$destination = 'C:/upload_test';
$max_size = '50kB';
$not_allowed = 'exe,vbs,shs,pif,lnk,dll';
if (!isset($_SESSION['att_id'])) {
  $_SESSION['att_id'] = 'att' . time() .'-';
  $_SESSION['attachments'] = array();

  // set the destination for the upload
  $uploader = new Zend_File_Transfer_Adapter_Http();
  $uploader->setDestination($destination);
  // permit blank file fields
  $uploader->setOptions(array('ignoreNoFile' => TRUE));
  // set the validation criteria
  $uploader->addValidator('Size', FALSE, $max_size);
  $uploader->addValidator('ExcludeExtension', FALSE, $not_allowed);
  
  // get the details of the uploaded files
  $files = $uploader->getFileInfo();
  // loop through the files and deal with each file individually
  foreach($files as $file => $info) {
	// make sure a file has been uploaded
	if ($uploader->isUploaded($file)) {
	  // get the file's name and replace spaces with underscores
	  $filename = $uploader->getFileName($file, FALSE);
	  if (!$uploader->isValid($file)) {
		$messages[] = "$filename exceeds $max_size or is not an acceptable type";
	  } else {
		$attachment = $_SESSION['att_id'] . str_replace(' ', '_', $filename);
	  
		$uploader->addFilter('Rename', array('target' => $attachment), $file);
		$success = $uploader->receive($file);
		// if the transfer failed, get the error messages
		if (!$success) {
		  $messages[] = "$filename could not be attached";
		} else {
		  // the transfer was OK, so tell the user what happened
		  $messages[] = "$filename attached";
		  $_SESSION['attachments'][] = $filename;
		}
	  }
	}
  }
}