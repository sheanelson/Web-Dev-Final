<?php
require_once('library.php');
$errors = array();
try {
  $public_key = 'Your_public_key';
  $private_key = 'Your_private_key';
  $recaptcha = new Zend_Service_ReCaptcha($public_key, $private_key);
  if (isset($_POST['send'])) {
	// validate the user input
	if (empty($_POST['recaptcha_response_field'])) {
	  $errors['recaptcha'] = 'reCAPTCHA field is required';
	} else {
	  $result = $recaptcha->verify($_POST['recaptcha_challenge_field'], $_POST['recaptcha_response_field']);
	  if (!$result->isValid()) {
		$errors['recaptcha'] = 'Try again';
	  }
	}
	$val = new Zend_Validate_Alnum(TRUE);
	if (!$val->isValid($_POST['name'])) {
	  $errors['name'] = 'Name is required';
	}
	$val = new Zend_Validate_EmailAddress();
	if (!$val->isValid($_POST['email'])) {
	  $errors['email'] = 'Email address is required';
	}
	$val = new Zend_Validate_StringLength(10);
	if (!$val->isValid($_POST['comments'])) {
	  $errors['comments'] = 'Required';
	}
	require_once('get_attachments.php');
	if (!$errors) {
	   // create and send the email
	   require_once('mail_connector.php');
	   $mail = new Zend_Mail('UTF-8');
	   $mail->addTo('me@example.com', 'A N Other');
	   $mail->setFrom('webmaster@example.com', 'Zend Mail Test');
	   $mail->setSubject('Comments from feedback form');
	   $mail->setReplyTo($_POST['email'], $_POST['name']);
	   $text = "Name: {$_POST['name']}\r\n\r\n";
	   $text .= "Email: {$_POST['email']}\r\n\r\n";
	   $text .= "Comments: {$_POST['comments']}";
	   $html = '<html><head><title>';
	   $html .= $mail->getSubject();
	   $html .= '</title></head><body>';
	   $html .= "<p><strong>Name: </strong><a href='mailto:{$_POST['email']}'>{$_POST['name']}</a></p>";
	   $html .= '<p><strong>Comments: </strong>' . nl2br($_POST['comments']) . '</p>';
	   $html .= '</body></html>';
	   $mail->setBodyText($text, 'UTF-8');
	   $mail->setBodyHtml($html, 'UTF-8');
	   if (isset($_SESSION['attachments']) && !empty($_SESSION['attachments'])) {
		  foreach($_SESSION['attachments'] as $attached) {
			$current_file = $destination . '/' . $_SESSION['att_id'] . $attached;
			$contents = file_get_contents($current_file);
			$att = $mail->createAttachment($contents);
			$att->filename = $attached;
			unlink($current_file);
		  }
		  unset($_SESSION['attachments']);
		  unset($_SESSION['att_id']);
	   }
	   $success = $mail->send();
	   if (!$success) {
	     $errors = TRUE;
	   }
	}
  }
} catch (Exception $e) {
  echo $e->getMessage();
}
?>