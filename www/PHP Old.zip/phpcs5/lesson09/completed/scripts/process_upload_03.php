<?php
if (isset($_POST['upload'])) {
  require_once('library.php');
  try {
	$destination = 'C:/upload_test';
	$uploader = new Zend_File_Transfer_Adapter_Http();
	$uploader->setDestination($destination);
    $filename = $uploader->getFileName(NULL, FALSE);
	$uploader->addValidator('Size', FALSE, '50kB');
	$uploader->addValidator('MimeType', FALSE, 'image');
	$uploader->addValidator('ImageSize', FALSE, array('minheight' => 50, 'minwidth' => 100));
	$uploader->addValidator('NotExists', FALSE, $destination);
	$no_spaces = str_replace(' ', '_', $filename, $renamed);
    $uploader->addFilter('Rename', array('target' => $no_spaces));
	$success = $uploader->receive();
	if (!$success) {
	  $messages = $uploader->getMessages();
	} else {
	  $uploaded = "$filename uploaded successfully";
	  if ($renamed) {
		$uploaded .= " and renamed $no_spaces";
	  }
	  $messages[] = $uploaded;
	}
  } catch (Exception $e) {
	echo $e->getMessage();
  }
}