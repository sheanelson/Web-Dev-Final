<?php
if (isset($_POST['upload'])) {
  require_once('library.php');
  try {
	$destination = 'C:/upload_test';
	$uploader = new Zend_File_Transfer_Adapter_Http();
	$uploader->setDestination($destination);
	$uploader->receive();
  } catch (Exception $e) {
	echo $e->getMessage();
  }
}