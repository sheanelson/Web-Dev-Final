<?php
if (isset($_POST['upload'])) {
  require_once('library.php');
   $overwrite = FALSE;
  if (isset($_POST['overwrite']) && $_POST['overwrite'] == 'y') {
	$overwrite = TRUE;
  }
  try {
	$destination = 'C:/upload_test';
	$uploader = new Zend_File_Transfer_Adapter_Http();
	$uploader->setDestination($destination);
    $filename = $uploader->getFileName(NULL, FALSE);
	$uploader->addValidator('Size', FALSE, '50kB');
	$uploader->addValidator('MimeType', FALSE, 'image');
	$uploader->addValidator('ImageSize', FALSE, array('minheight' => 50, 'minwidth' => 100));
	if (!$uploader->isValid()) {
      $messages = $uploader->getMessages();
	} else {
	  $no_spaces = str_replace(' ', '_', $filename, $renamed);
	  $uploader->addValidator('Extension', FALSE, 'gif, png, jpg');
	  $recognized = FALSE;
	  if ($uploader->isValid()) {
		$recognized = TRUE;
	  } else {
		$mime = $uploader->getMimeType();
		$acceptable = array('jpg' => 'image/jpeg' ,
		                    'png' => 'image/png',
							'gif' => 'image/gif');
		$key = array_search($mime, $acceptable);
		if (!$key) {
		  $messages[] = 'Unrecognized image type';
		} else {
		  $no_spaces = "$no_spaces.$key";
		  $recognized = TRUE;
		  $renamed = TRUE;
		}
	  } 
      $uploader->clearValidators();	  
	  if ($recognized) {
		if (!$overwrite) {
		  // get the names of existing files
		  $existing = scandir($destination);
		  // check if the name of the uploaded file is in the array
		  if (in_array($no_spaces, $existing)) {
			// get the position of the final period
			// use it to get the base name and extension
			$dot = strrpos($no_spaces, '.');
			$base = substr($no_spaces, 0, $dot);
			$extension = substr($no_spaces, $dot);
			// initialize a counter
			$i = 1;
			// use a loop to add the counter after the base name
			// check whether the new name exists in the array
			do {
			  $no_spaces = $base . '_' . $i++ . $extension;
			}  while (in_array($no_spaces, $existing));
			// set $renamed to TRUE
			$renamed = TRUE;
		  }
		}
		$uploader->addFilter('Rename', array('target' => $no_spaces));
		$success = $uploader->receive();
		if (!$success) {
		  $messages = $uploader->getMessages();
		} else {
		  $uploaded = "$filename uploaded successfully";
		  if ($renamed) {
			$uploaded .= " and renamed $no_spaces";
		  }
		  $messages[] = $uploaded;
		}
	  }
	}
  } catch (Exception $e) {
	echo $e->getMessage();
  }
}