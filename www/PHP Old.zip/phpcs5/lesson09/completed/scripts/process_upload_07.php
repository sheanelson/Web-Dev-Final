<?php
if (isset($_POST['upload'])) {
  require_once('library.php');
  $overwrite = FALSE;
  if (isset($_POST['overwrite']) && $_POST['overwrite'] == 'y') {
	$overwrite = TRUE;
  }
  try {
	// set the destination for the upload
	$destination = 'C:/upload_test';
	$uploader = new Zend_File_Transfer_Adapter_Http();
	$uploader->setDestination($destination);
	// permit blank file fields
	$uploader->setOptions(array('ignoreNoFile' => TRUE));
	// get the details of the uploaded files
	$files = $uploader->getFileInfo();
	// loop through the files and deal with each file individually
	foreach ($files as $file => $info) {
	  // make sure a file has been uploaded
	  if ($uploader->isUploaded($file)) {
		// if a file has been uploaded, get its name
		$filename = $uploader->getFileName($file, FALSE);
		// set the validation criteria
		$uploader->addValidator('Size', FALSE, '50kB');
	    $uploader->addValidator('MimeType', FALSE, 'image');
	    $uploader->addValidator('ImageSize', FALSE, array('minheight' => 50, 'minwidth' => 100));
		// did the file pass validation?
		if (!$uploader->isValid($file)) {
		  // if validation failed, get the error codes
		  $error_codes = $uploader->getErrors();
		  // if the codes include 'fileMimeTypeFalse', create a custom message
          if (in_array('fileMimeTypeFalse', $error_codes)) {
            $messages[] = "$filename is not an image";
          } else {
			// otherwise use the standard error messages
		    $messages[] = implode('. ', $uploader->getMessages());
          }
		// the file is uploaded and valid, so process it
		} else {
		  // replace spaces in the file name with underscores
		  $no_spaces = str_replace(' ', '_', $filename, $renamed);
		  // add a validator to check the filename extesnion
		  $uploader->addValidator('Extension', FALSE, 'gif, png, jpg');
		  // assume the extension is not recognized
		  $recognized = FALSE;
		  // if it passes validation, reset $recognized to TRUE
		  if ($uploader->isValid($file)) {
			$recognized = TRUE;
		  // otherwise get the MIME type
		  } else {
			$mime = $uploader->getMimeType($file);
			// create an array of acceptable MIME types
			$acceptable = array('jpg' => 'image/jpeg' ,
								'png' => 'image/png',
								'gif' => 'image/gif');
			// check if the file's MIME type is in the $acceptable array
			$key = array_search($mime, $acceptable);
			if (!$key) {
			  $messages[] = 'Unrecognized image type';
			// the MIME type is OK, so add the filename extension to the name
			// and reset $recognized and $renamed
			} else {
			  $no_spaces = "$no_spaces.$key";
			  $recognized = TRUE;
			  $renamed = TRUE;
			}
		  } 
		  // if the file is of a recognized MIME type, carry on
		  if ($recognized) {
			// if the user doesn't want to overwrite existing files,
		    // make sure a file of the same name doesn't already exist
		    // and rename the file, if necessary
			if (!$overwrite) {
			  // get the names of existing files
			  $existing = scandir($destination);
			  // check if the name of the uploaded file is in the array
			  if (in_array($no_spaces, $existing)) {
				// get the position of the final period
				// use it to get the base name and extension
				$dot = strrpos($no_spaces, '.');
				$base = substr($no_spaces, 0, $dot);
				$extension = substr($no_spaces, $dot);
				// initialize a counter
				$i = 1;
				// use a loop to add the counter after the base name
				// check whether the new name exists in the array
				do {
				  $no_spaces = $base . '_' . $i++ . $extension;
				}  while (in_array($no_spaces, $existing));
				// set $renamed to TRUE
				$renamed = TRUE;
			  }
			}
			// clear the validators to prevent problems with uploading
			// files that didn't originally have a filename extension
			$uploader->clearValidators();
			// apply any name changes to the uploaded file and transfer it
			$uploader->addFilter('Rename', array('target' => $no_spaces, $info['tmp_name']));
			$success = $uploader->receive($file);
			// if the transfer failed, get the error messages
			if (!$success) {
			  $messages[] = implode('. ', $uploader->getMessages());
			} else {
			  // the transfer was OK, so tell the user what happened
			  $uploaded = "$filename uploaded successfully";
			  if ($renamed) {
				$uploaded .= " and renamed $no_spaces";
			  }
			  $messages[] = $uploaded;
			}
		  }
		}
	  }
	}
  } catch (Exception $e) {
	echo $e->getMessage();
  }
}