<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Insert Photos</title>
<link href="../styles/admin.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Insert Photos</h1>
<p><a href="menu.php">Admin menu</a></p>
<?php
if ($errors) {
  echo '<ul>';
  foreach ($errors as $item) {
	echo "<li>$item</li>";
  }
  echo '</ul>';
}
if (isset($messages)) {
  echo '<ul>';
  foreach ($messages as $item) {
	echo "<li>$item</li>";
  }
  echo '</ul>';
}
?>
<form action="" method="post" enctype="multipart/form-data" name="form1" id="form1">
  <p>
    <label for="photo1">Photo 1:</label>
    <input type="file" name="photo1" id="photo1" />
  </p>
  <p>
    <label for="caption1">Caption for photo 1</label>
    <input type="text" name="caption1" id="caption1" />
  </p>
  <p>
    <label for="place_id1">Associate photo 1 with:</label>
    <select name="place_id1" id="place_id1">
      <option value="0">-- Select place --</option>
    </select>
  </p>
  <p>
    <input type="submit" name="insert" id="insert" value="Insert Photo(s)" />
  </p>
</form>
</body>
</html>