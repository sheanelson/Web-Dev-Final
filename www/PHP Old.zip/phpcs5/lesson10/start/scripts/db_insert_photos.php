<?php
$errors = array();
require_once('library.php');
try {
  
} catch (Exception $e) {
  echo $e->getMessage();
}