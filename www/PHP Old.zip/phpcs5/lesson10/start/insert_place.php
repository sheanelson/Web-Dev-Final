<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Insert New Place</title>
<link href="../styles/admin.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Insert New Place</h1>
<p><a href="menu.php">Admin menu</a></p>
<?php
if ($errors) {
  echo '<ul>';
  foreach ($errors as $item) {
	echo "<li>$item</li>";
  }
  echo '</ul>';
}
if (isset($messages)) {
  echo '<ul>';
  foreach ($messages as $item) {
	echo "<li>$item</li>";
  }
  echo '</ul>';
}
?>
<form action="" method="post" enctype="multipart/form-data" name="form1" id="form1">
  <p>
    <label for="name">Place name:</label>
    <input value="<?php if ($_POST && $errors) {
  echo htmlentities($_POST['name'], ENT_COMPAT, 'UTF-8');
}?>" type="text" name="name" id="name" />
  </p>
  <p>
    <label for="state_id">State:</label>
    <select name="state_id" id="state_id">
    </select>
  </p>
  <p>
    <label for="description">Description:</label>
    <textarea name="description" id="description" cols="45" rows="5"><?php if ($_POST && $errors) { echo htmlentities($_POST['description'], ENT_COMPAT, 'UTF-8');}?></textarea>
  </p>
  <p>
    <label for="photo1">Photo 1:</label>
    <input type="file" name="photo1" id="photo1" />
  </p>
  <p>
    <label for="caption1">Caption for photo 1:</label>
    <input value="<?php if ($_POST && $errors) {
  echo htmlentities($_POST['caption1'], ENT_COMPAT, 'UTF-8');
}?>" type="text" name="caption1" id="caption1" />
  </p>
  <p>
    <input type="submit" name="insert" id="insert" value="Insert Place" />
  </p>
</form>
</body>
</html>