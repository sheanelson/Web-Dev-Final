<?php
$errors = array();
require_once('library.php');
try {
  require_once('db_definitions.php');
  $states = getAllStates($dbRead);
  if (isset($_POST['insert'])) {
	validatePlaceName($_POST['name'], $errors);
	$val = new Zend_Validate_StringLength($descriptionMin, $descriptionMax);
	validateDescription($_POST['description'], $val, $errors);
	$val->setMin($captionMin);
	$val->setMax($captionMax);
	for ($num = 1; $num <= $photofields; $num++) {
	  validateCaption($_POST["caption{$num}"], $num, $val, $errors);
	}
	if (!$errors) {
	  checkDuplicatePlacename($dbRead, $_POST['name'], $errors);
	}
	if (!$errors) {
      require_once('upload_images.php');
	}
  }
} catch (Exception $e) {
  echo $e->getMessage();
}