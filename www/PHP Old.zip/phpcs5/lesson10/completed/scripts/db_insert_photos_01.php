<?php
$errors = array();
require_once('library.php');
try {
  require_once('db_definitions.php');
  $places = getAllPlaces($dbRead);
} catch (Exception $e) {
  echo $e->getMessage();
}