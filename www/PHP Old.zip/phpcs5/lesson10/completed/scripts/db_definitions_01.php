<?php
$captionMin = 0;
$captionMax = 150;
$descriptionMin = 10;
$descriptionMax = NULL;
$photofields = 3;

function getAllStates($read) {
  $sql = 'SELECT * FROM states ORDER BY state_name';
  return $read->fetchAll($sql);
}

function validatePlaceName($name, &$errors) {
  $val = new Zend_Validate_Regex('/^[a-z]+[-\'a-z ]+$/i');
  if (!$val->isValid($name)) {
	$errors['name'] = 'Place name is required: no special characters';
  }
}

function validateDescription($description, $val, &$errors) {
  if (!$val->isValid($description)) {
    $errors['description'] = 'Description is required';
  }
}

function validateCaption($caption, $num, $val, &$errors) {
  if (!$val->isValid($caption)) {
    $errors["photo{$num}"] = "Caption for photo $num is too long"; 
  }
}

function checkDuplicatePlacename ($read, $name, &$errors) {
  $sql = $read->quoteInto('SELECT place_id FROM places WHERE name = ?', $name);
  $result = $read->fetchAll($sql);
  if ($result) {
	$errors['name'] = $_POST['name'] . ' is already listed';
  }
}