<?php
$uploader = new Zend_File_Transfer_Adapter_Http();
$uploader->setDestination($destination);
$uploader->setOptions(array('ignoreNoFile' => TRUE));
$files = $uploader->getFileInfo();
$filenum = 1;
foreach ($files as $file => $info) {
  $file = "photo{$filenum}";
  $caption = $_POST["caption{$filenum}"];
  if (isset($_POST["place_id{$filenum}"])) {
    $place_id = $_POST["place_id{$filenum}"];
  } else {
    $place_id = NULL;
  }
  $filenum++;
  if ($uploader->isUploaded($file)) {
	$filename = $uploader->getFileName($file, FALSE);
	$uploader->addValidator('Size', FALSE, '50kB');
	$uploader->addValidator('MimeType', FALSE, 'image');
	$uploader->addValidator('ImageSize', FALSE, array('minheight' => 50, 'minwidth' => 100));
	if (!$uploader->isValid($file)) {
	  $errors[$filename] = "$filename doesn't meet the requirements for an image";
	} else {
	  $no_spaces = str_replace(' ', '_', $filename, $renamed);
	  $uploader->addValidator('Extension', FALSE, 'gif, png, jpg');
	  $recognized = FALSE;
	  if ($uploader->isValid($file)) {
		$recognized = TRUE;
	  } else {
		$mime = $uploader->getMimeType($file);
		$acceptable = array('jpg' => 'image/jpeg' ,
							'png' => 'image/png',
							'gif' => 'image/gif');
		$key = array_search($mime, $acceptable);
		if (!$key) {
		  $errors[$no_spaces] = "$filename is an unrecognized image type";
		} else {
		  $no_spaces = "$no_spaces.$key";
		  $recognized = TRUE;
		  $renamed = TRUE;
		}
	  } 
	  if ($recognized) {
		// get the names of existing files
		$existing = scandir($destination);
		// check if the name of the uploaded file is in the array
		if (in_array($no_spaces, $existing)) {
		  // get the position of the final period
		  // use it to get the base name and extension
		  $dot = strrpos($no_spaces, '.');
		  $base = substr($no_spaces, 0, $dot);
		  $extension = substr($no_spaces, $dot);
		  // initialize a counter
		  $i = 1;
		  // use a loop to add the counter after the base name
		  // check whether the new name exists in the array
		  do {
			$no_spaces = $base . '_' . $i++ . $extension;
		  }  while (in_array($no_spaces, $existing));
		  // set $renamed to TRUE
		  $renamed = TRUE;
		}
		$uploader->clearValidators();
		$uploader->addFilter('Rename', array('target' => $no_spaces, $info['tmp_name']));
		$success = $uploader->receive($file);
		if (!$success) {
		  $errors[$no_spaces] = implode('. ', $uploader->getMessages());
		} else {
		  $uploaded = "$filename uploaded successfully";
		  if ($renamed) {
			$uploaded .= " and renamed $no_spaces";
		  }
		  $images[] = array('filename' => $no_spaces,
                    'caption'  => $caption,
                    'place_id' => $place_id);
		  $messages[] = $uploaded;
		}
	  }
	}
  }
}
