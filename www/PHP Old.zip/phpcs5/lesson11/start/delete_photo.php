<?php
require_once('scripts/library.php');
try {
  require_once('scripts/db_definitions.php');
  $photo_id = checkId('photo_id', 'list_photos.php');
  $photo = getPhotoDetails($dbRead, $photo_id);
  unlink($destination . '/' . $photo['filename']);
  $dbWrite->delete('photos', "photo_id = $photo_id");
  $dbWrite->delete('place2photo', "photo_id = $photo_id");
  if (isset($_SERVER['HTTP_REFERER'])) {
    $returnto = $_SERVER['HTTP_REFERER'];
  } else {
    $returnto = 'list_photos.php';
  }
  header("Location: $returnto");
  exit;
} catch (Exception $e) {
  echo $e->getMessage();
}