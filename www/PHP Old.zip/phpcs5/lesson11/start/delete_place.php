<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Delete Place</title>
<link href="../styles/admin.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Delete Place</h1>
<p><a href="menu.php">Admin menu</a></p>
<p>Please confirm that you want to delete the following record. This cannot be undone.</p>
<form id="form1" name="form1" method="post" action="">
<p><strong>Place name:</strong></p>
<p><strong>State:</strong></p>
<p>The following photos are linked with this place. Select the checkbox next to each photo you want to delete at the same time as this place. To delete images without deleting the place, use <a href="list_photos.php">photo management page</a>.</p>
<table width="600">
  <tr>
    <td><input type="checkbox" name="photo1" id="photo1" />
      <label for="photo1" class="checkbox_label">Delete photo</label></td>
    <td>&nbsp;</td>
    </tr>
</table>
<p>
  <input type="submit" name="delete_place" id="delete_place" value="Confirm Deletion" />
  <input type="submit" name="cancel" id="cancel" value="Cancel" />
</p>
</form>
</body>
</html>