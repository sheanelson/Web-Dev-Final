<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Manage Photos</title>
<link href="../styles/admin.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Manage Photos</h1>
<p><a href="menu.php">Admin menu</a></p>
<table width="960">
<colgroup>
<col width="210" />
<col width="210" />
<col width="275" />
<col width="140" />
<col width="50" />
<col width="75" />
</colgroup>
  <tr>
    <th scope="col">Photo</th>
    <th scope="col">Filename</th>
    <th scope="col">Caption</th>
    <th scope="col">Places</th>
    <th scope="col">&nbsp;</th>
    <th scope="col">&nbsp;</th>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>EDIT</td>
    <td>DELETE</td>
  </tr>
</table>
<p id="paginator">
</p>
</body>
</html>