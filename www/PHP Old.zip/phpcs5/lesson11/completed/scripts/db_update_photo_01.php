<?php
$errors = array();
require_once('library.php');
try {
  require_once('db_definitions.php');
  $photo_id = checkId('photo_id', 'list_photos.php');
  if (isset($_POST['update_photo'])) {
	// update and redirect
  }
  $photo = getPhotoDetails($dbRead, $photo_id);
  $places = getAllPlaces($dbRead);
  $related = getRelatedPlaces($dbRead, $photo_id);
  if (isset($_SERVER['HTTP_REFERER'])) {
    $returnto = $_SERVER['HTTP_REFERER'];
  } else {
    $returnto = 'list_photos.php';
  }
} catch (Exception $e) {
  echo $e->getMessage();
}