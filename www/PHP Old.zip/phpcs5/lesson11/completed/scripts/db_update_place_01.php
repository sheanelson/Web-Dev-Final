<?php
$errors = array();
require_once('library.php');
try {
  require_once('db_definitions.php');
  $place_id = checkId('place_id', 'list_places.php');
  $states = getAllStates($dbRead);
  $place = getPlace($dbRead, $place_id);
  $photos = getRelatedPhotos($dbRead, $place_id);
  if (isset($_SERVER['HTTP_REFERER'])) {
    $returnto = $_SERVER['HTTP_REFERER'];
  } else {
    $returnto = 'list_places.php';
  }
} catch (Exception $e) {
  echo $e->getMessage();
}