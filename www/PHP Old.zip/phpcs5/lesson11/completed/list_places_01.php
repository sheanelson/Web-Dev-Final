<?php
require_once('scripts/library.php');
try {
  $places = $dbRead->select()
                 ->from('places', array('place_id', 'name'))
				 ->joinUsing('states', 'state_id', array('state_name'))
				 ->order(array('state_name', 'name'));
  
  $paginator = Zend_Paginator::factory($places);
  if (isset($_GET['page'])) {
	$paginator->setCurrentPageNumber($_GET['page']);
  }
  $paginator->setItemCountPerPage(2);
  $paginator->setPageRange(3);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Manage Places</title>
<link href="../styles/admin.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Manage Places</h1>
<p><a href="menu.php">Admin menu</a></p>
<table width="600">
  <colgroup>
  <col width="150" />
  <col width="300" />
  <col width="75" />
  <col width="75" />
  </colgroup>
  <tr>
    <th scope="col">State</th>
    <th scope="col">Name</th>
    <th scope="col">&nbsp;</th>
    <th scope="col">&nbsp;</th>
  </tr>
  <?php foreach($paginator as $row) { // paginator repeat region ?>
  <tr>
    <td><?php echo $row['state_name']; ?></td>
    <td><?php echo $row['name']; ?></td>
    <td>EDIT</td>
    <td>DELETE</td>
  </tr>
  <?php } // end of paginator repeat region ?>
</table>
<p>
  <?php
$pages = $paginator->getPages('Elastic');
if (isset($pages->previous)) {
  echo '<a href="' . $_SERVER['PHP_SELF'] . '?page=' . $pages->previous . '">Prev</a>';
}
foreach ($pages->pagesInRange as $page) {
  if ($page != $pages->current) {
    echo " <a href='" . $_SERVER['PHP_SELF'] . "?page={$page}'>$page</a>";
  } else {
    echo ' ' . $page;
  }
}
if (isset($pages->next)) {
  echo ' <a href="' . $_SERVER['PHP_SELF'] . '?page=' . $pages->next . '">Next</a>';
}
?>
</p>
</body>
</html>
</html>
<?php
} catch (Exception $e) {
  echo $e->getMessage();
}
?>