<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>What time is it?</title>
</head>

<body>
<p>The time in London is <?php 
$now = new DateTime();
$now->setTimezone(new DateTimeZone('Europe/London'));
echo $now->format('g.i a');
?></p>
<p>In Los Angeles, it's <?php
$now->setTimezone(new DateTimeZone('America/Los_Angeles'));
echo $now->format('g.i a');
?></p>
</body>
</html>
