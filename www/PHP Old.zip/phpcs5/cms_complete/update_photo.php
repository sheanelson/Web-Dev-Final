<?php
require_once('scripts/db_update_photo.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Update Photo Details</title>
<link href="../styles/admin.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Update Photo Details</h1>
<?php
if ($errors) {
  echo '<ul>';
  foreach ($errors as $item) {
	echo "<li>$item</li>";
  }
  echo '</ul>';
}
?>
<p><a href="menu.php">Admin menu</a></p>
<p><img src="image_upload/<?php echo $photo['filename']; ?>" alt="" /></p>
<form id="form1" name="form1" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
  <p>
    <label for="caption">Caption:</label>
    <input type="text" name="caption" id="caption" value="<?php if (!$errors) {
	  echo $photo['caption'];
	} else {
	  echo $_POST['caption'];
	}?>" />
  </p>
  <p>
    <label for="places">Related places:</label>
    <select name="places[]" size="6" multiple="multiple" id="places">
    <?php
foreach ($places as $row) {
  echo "<option value='{$row['place_id']}'";
  if (!$errors && in_array($row['place_id'], $related)) {
	echo ' selected="selected"';
  } elseif ($errors && isset($_POST['places']) && in_array($row['place_id'], $_POST['places'])) {
	echo ' selected="selected"';
  }
  echo ">{$row['name']}</option>";
	}
?>
    </select>
  </p>
  <p>
    <input type="submit" name="update_photo" id="update_photo" value="Update Photo Details" />
    <input name="photo_id" type="hidden" id="photo_id" value="<?php echo $photo_id; ?>" />
    <input name="returnto" type="hidden" id="returnto" value="<?php echo $returnto; ?>" />
  </p>
</form>
</body>
</html>