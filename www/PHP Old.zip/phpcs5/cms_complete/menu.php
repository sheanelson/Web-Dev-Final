<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Admin Menu</title>
<link href="../styles/admin.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Admininstration Menu</h1>
<p><a href="insert_place.php">Insert new place</a></p>
<p><a href="insert_photos.php">Insert new photos</a></p>
<p><a href="list_places.php">Manage places</a></p>
<p><a href="list_photos.php">Manage photos</a></p>
</body>
</html>