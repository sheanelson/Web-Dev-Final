<?php
// Adjust the path to match the location of the library folder on your system
$library = 'C:/php_library/ZendFramework/library';
set_include_path(get_include_path() . PATH_SEPARATOR . $library);
require_once('Zend/Loader/Autoloader.php');
try {
  Zend_Loader_Autoloader::getInstance();
  $write = array('host'     => 'localhost',
				 'username' => 'cs5write',
				 'password' => 'Bow!e#CS5',
				 'dbname'   => 'phpcs5');
  $read  = array('host'     => 'localhost',
				 'username' => 'cs5read',
				 'password' => '5T@rmaN',
				 'dbname'   => 'phpcs5');
  
  // Comment out the next two lines if using mysqli
  // and remove the comments from the last two lines
  $dbWrite = new Zend_Db_Adapter_Pdo_Mysql($write);
  $dbRead = new Zend_Db_Adapter_Pdo_Mysql($read);
  
  //$dbWrite = new Zend_Db_Adapter_Mysqli($write);
  //$dbRead = new Zend_Db_Adapter_Mysqli($read);
} catch (Exception $e) {
	echo $e->getMessage();
}