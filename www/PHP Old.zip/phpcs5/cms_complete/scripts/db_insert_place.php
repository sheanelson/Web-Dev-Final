<?php
$errors = array();
require_once('library.php');
try {
  require_once('db_definitions.php');
  $states = getAllStates($dbRead);
  if (isset($_POST['insert'])) {
	validatePlaceName($_POST['name'], $errors);
	$val = new Zend_Validate_StringLength($descriptionMin, $descriptionMax);
	validateDescription($_POST['description'], $val, $errors);
	$val->setMin($captionMin);
	$val->setMax($captionMax);
	for ($num = 1; $num <= $photofields; $num++) {
	  validateCaption($_POST["caption{$num}"], $num, $val, $errors);
	}
	if (!$errors) {
	  checkDuplicatePlacename($dbRead, $_POST['name'], $errors);
	}
	if (!$errors) {
      require_once('upload_images.php');
	}
	if (!$errors) {
	  $data = array('name'        => $_POST['name'],
	                'state_id'    => $_POST['state_id'],
					'description' => $_POST['description'],
					'link_name'   => str_replace(' ', '', $_POST['name']),
					'created'     => new Zend_Db_Expr('NOW()'));
	  $inserted = $dbWrite->insert('places', $data);
	  if ($inserted && isset($images)) {
		$place_id = $dbWrite->lastInsertId();
		foreach($images as $image) {
		  $data = array('filename' => $image['filename'],
						'caption'  => $image['caption']);
		  $dbWrite->insert('photos', $data);
		  $photo_id = $dbWrite->lastInsertId();
		  $data = array('place_id' => $place_id,
						'photo_id' => $photo_id);
		  $dbWrite->insert('place2photo', $data);
		}
	  }
	  if ($inserted) {
		$messages[] = $_POST['name'] . ' is now listed in the database';
	  } else {
		$errors[] = $_POST['name'] . ' could not be inserted';
	  }
    }
  }
} catch (Exception $e) {
  echo $e->getMessage();
}