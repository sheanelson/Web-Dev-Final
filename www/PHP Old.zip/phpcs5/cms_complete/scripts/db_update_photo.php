<?php
$errors = array();
require_once('library.php');
try {
  require_once('db_definitions.php');
  $photo_id = checkId('photo_id', 'list_photos.php');
  if (isset($_POST['update_photo'])) {
	// update and redirect
	$val = new Zend_Validate_StringLength($captionMin, $captionMax);
	if (!$val->isValid($_POST['caption'])) {
	  $errors['caption'] = "Caption exceeds $captionMax characters";
	}
	if (!$errors) {
	  $data = array('caption' => $_POST['caption']);
	  $dbWrite->update('photos', $data, "photo_id = $photo_id");
	  $dbWrite->delete('place2photo', "photo_id = $photo_id");
	  if (isset($_POST['places'])) {
		foreach ($_POST['places'] as $place) {
		  $data = array('place_id' => $place,
		                'photo_id' => $photo_id);
		  $dbWrite->insert('place2photo', $data);
		}
		header('Location: ' . $_POST['returnto']);
		exit;
	  }
	}
  }
  $photo = getPhotoDetails($dbRead, $photo_id);
  $places = getAllPlaces($dbRead);
  $related = getRelatedPlaces($dbRead, $photo_id);
  if (isset($_SERVER['HTTP_REFERER'])) {
    $returnto = $_SERVER['HTTP_REFERER'];
  } else {
    $returnto = 'list_photos.php';
  }
} catch (Exception $e) {
  echo $e->getMessage();
}