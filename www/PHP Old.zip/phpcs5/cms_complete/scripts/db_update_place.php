<?php
$errors = array();
require_once('library.php');
try {
  require_once('db_definitions.php');
  $place_id = checkId('place_id', 'list_places.php');
  if (isset($_POST['update_place'])) {
	validatePlaceName($_POST['name'], $errors);
	$val = new Zend_Validate_StringLength($descriptionMin, $descriptionMax);
	validateDescription($_POST['description'], $val, $errors);
	$val = new Zend_Validate_Alnum();
	if (!$val->isValid($_POST['link_name'])) {
	   $errors['link_name'] = 'Link name must be alphanumeric characters only; no spaces'; 
	}
	if (!$errors) {
	  checkDuplicatePlacename($dbRead, $_POST['name'], $errors, $place_id);
	  checkLinkname($dbRead, $_POST['link_name'], $errors, $place_id);
	  if (!$errors) {
		// update the record and redirect
		$data = array('name' => $_POST['name'],
					  'state_id' => $_POST['state_id'],
					  'description' => $_POST['description'],
					  'link_name' => $_POST['link_name']);
		$dbWrite->update('places', $data, "place_id = $place_id");
		header('Location: ' . $_POST['returnto']);
		exit;
	  }
	}
  }
  $states = getAllStates($dbRead);
  $place = getPlace($dbRead, $place_id);
  $photos = getRelatedPhotos($dbRead, $place_id);
  if (isset($_SERVER['HTTP_REFERER'])) {
    $returnto = $_SERVER['HTTP_REFERER'];
  } else {
    $returnto = 'list_places.php';
  }
} catch (Exception $e) {
  echo $e->getMessage();
}