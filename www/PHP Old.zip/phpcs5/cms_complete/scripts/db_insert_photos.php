<?php
$errors = array();
require_once('library.php');
try {
  require_once('db_definitions.php');
  $places = getAllPlaces($dbRead);
  if (isset($_POST['insert'])) {
	$val = new Zend_Validate_StringLength($captionMin, $captionMax);
	for ($num = 1; $num <= $photofields; $num++) {
      validateCaption($_POST["caption{$num}"], $num, $val, $errors);
	}
	if (!$errors) {
	  require_once('upload_images.php');
	}
	if (isset($images)) {
	  foreach($images as $image) {
		if (!array_key_exists($image['filename'], $errors)) {
		  $data = array('filename' => $image['filename'],
						'caption'  => $image['caption']);
		  $dbWrite->insert('photos', $data);
		  $photo_id = $dbWrite->lastInsertId();
		  if ($image['place_id']) {
			$data = array('place_id' => $image['place_id'],
						  'photo_id' => $photo_id);
			$dbWrite->insert('place2photo', $data);
		  }
		}
	  }
	}
  }
} catch (Exception $e) {
  echo $e->getMessage();
}