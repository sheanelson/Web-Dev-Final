<?php
require_once('scripts/library.php');
try {
  $photos = $dbRead->select()->from('photos')->order('filename');
  require_once('scripts/db_definitions.php');
?>
<?php
$paginator = Zend_Paginator::factory($photos);
if (isset($_GET['page'])) {
  $paginator->setCurrentPageNumber($_GET['page']);
}
$paginator->setItemCountPerPage(3);
$paginator->setPageRange(5);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Manage Photos</title>
<link href="../styles/admin.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Manage Photos</h1>
<p><a href="menu.php">Admin menu</a></p>
<table width="960">
<colgroup>
<col width="210" />
<col width="210" />
<col width="275" />
<col width="140" />
<col width="50" />
<col width="75" />
</colgroup>
  <tr>
    <th scope="col">Photo</th>
    <th scope="col">Filename</th>
    <th scope="col">Caption</th>
    <th scope="col">Places</th>
    <th scope="col">&nbsp;</th>
    <th scope="col">&nbsp;</th>
  </tr>
  <?php foreach($paginator as $row) { // paginator repeat region ?>
  <tr>
    <td><img src="image_upload/<?php echo $row['filename']; ?>" width="200" alt="" /></td>
    <td><?php echo $row['filename']; ?></td>
    <td><?php echo $row['caption']; ?></td>
    <td><?php $places = getRelatedPlaceNames($dbRead, $row['photo_id']);
	  echo implode('<br />', $places); ?></td>
    <td><a href="update_photo.php?photo_id=<?php echo $row['photo_id']; ?>">EDIT</a></td>
    <td><a href="delete_photo.php?photo_id=<?php echo $row['photo_id']; ?>">DELETE</a></td>
  </tr>
  <?php } // end of paginator repeat region ?>
</table>
<p id="paginator">
  <?php
$pages = $paginator->getPages('Elastic');
if (isset($pages->previous)) {
  echo '<a href="' . $_SERVER['PHP_SELF'] . '?page=' . $pages->previous . '">Prev</a>';
}
foreach ($pages->pagesInRange as $page) {
  if ($page != $pages->current) {
    echo " <a href='" . $_SERVER['PHP_SELF'] . "?page={$page}'>$page</a>";
  } else {
    echo ' ' . $page;
  }
}
if (isset($pages->next)) {
  echo ' <a href="' . $_SERVER['PHP_SELF'] . '?page=' . $pages->next . '">Next</a>';
}
?>
</p>
</body>
</html>
</html>
<?php
} catch (Exception $e) {
  echo $e->getMessage();
}
?>