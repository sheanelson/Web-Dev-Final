<?php
require_once('scripts/db_delete_place.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Delete Place</title>
<link href="../styles/admin.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Delete Place</h1>
<p><a href="menu.php">Admin menu</a></p>
<p>Please confirm that you want to delete the following record. This cannot be undone.</p>
<form id="form1" name="form1" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
<p><strong>Place name:</strong> <?php echo $place['name']; ?></p>
<p><strong>State:</strong> <?php echo $place['state_name']; ?></p>
<?php if ($photos) { ?>
<p>The following photos are linked with this place. Select the checkbox next to each photo you want to delete at the same time as this place. To delete images without deleting the place, use <a href="list_photos.php">photo management page</a>.</p>
<table width="600">
<?php 
$num = 0;
foreach ($photos as $photo) { ?>
  <tr>
    <td><input type="checkbox" name="photo[]" id="photo<?php echo $num; ?>" value="<?php echo $photo['filename']; ?>" />
      <label for="photo<?php echo $num++; ?>" class="checkbox_label">Delete photo</label></td>
    <td><img src="image_upload/<?php echo $photo['filename']; ?>" width="200" alt="" /><br /><?php echo $photo['caption']; ?></td>
    </tr>
<?php } ?>
</table>
<?php } ?>
<p>
  <input type="submit" name="delete_place" id="delete_place" value="Confirm Deletion" />
  <input type="submit" name="cancel" id="cancel" value="Cancel" />
  <input name="place_id" type="hidden" id="place_id" value="<?php echo $place_id; ?>" />
  <input name="returnto" type="hidden" id="returnto" value="<?php echo $returnto; ?>" />
</p>
</form>
</body>
</html>