<?php
require_once('scripts/db_update_place.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Update Place</title>
<link href="../styles/admin.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Update Place</h1>
<p><a href="menu.php">Admin menu</a></p>
<?php
if ($errors) {
  echo '<ul>';
  foreach ($errors as $item) {
	echo "<li>$item</li>";
  }
  echo '</ul>';
}
?>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="form1" id="form1">
  <p>
    <label for="name">Place name</label>
    <input type="text" name="name" id="name" value="<?php if (!$errors) {
	  echo $place['name'];
	} else {
	  echo $_POST['name'];
	}?>" />
  </p>
  <p>
    <label for="state_id">State:</label>
    <select name="state_id" id="state_id">
      <?php
foreach ($states as $row) {
  echo "<option value='{$row['state_id']}'";
  if ($errors && $row['state_id'] == $_POST['state_id']) {
	echo 'selected="selected"';
  } elseif (!$errors && $row['state_id'] == $place['state_id']) {
	echo 'selected="selected"';
  }
  echo ">{$row['state_name']}</option>";
	}
?>
    </select>
  </p>
  <p>
    <label for="description">Description:</label>
    <textarea name="description" id="description" cols="45" rows="5"><?php if (!$errors) {
	  echo $place['description'];
	} else {
	  echo $_POST['description'];
	}?></textarea>
  </p>
  <p>
    <label for="link_name">Link name:</label>
    <input type="text" name="link_name" id="link_name" value="<?php if (!$errors) {
	  echo $place['link_name'];
	} else {
	  echo $_POST['link_name'];
	}?>" />
  </p>
  <p>
    <input type="submit" name="update_place" id="update_place" value="Update Place" />
    <input name="returnto" type="hidden" id="returnto" value="<?php echo $returnto; ?>" />
    <input name="place_id" type="hidden" id="place_id" value="<?php echo $place_id; ?>" />
  </p>
</form>
<table width="600">
<colgroup>
<col width="210" />
<col width="240" />
<col width="75" />
<col width="75" />
</colgroup>
<?php foreach ($photos as $photo) { ?>
  <tr>
    <td><img src="image_upload/<?php echo $photo['filename']; ?>" width="200" alt="" /></td>
    <td><?php echo $photo['caption']; ?></td>
    <td><a href="update_photo.php?photo_id=<?php echo $photo['photo_id']; ?>">EDIT</a></td>
    <td><a href="delete_photo.php?photo_id=<?php echo $photo['photo_id']; ?>">DELETE</a></td>
  </tr>
<?php } ?>
</table>
</body>
</html>