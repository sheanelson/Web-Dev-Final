<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Array variables in double quotation marks</title>
<link href="../../styles/examples.css" rel="stylesheet" type="text/css" />
</head>

<body>
<?php $book = array('author' => 'David Powers',
                    'title'  => '"Adobe Dreamweaver CS5 with PHP"'); ?>
<h1>Array Variables Inside Double Quotation Marks</h1>
<p><?php echo "{$book['title']} by {$book['author']}"; ?></p>
</body>
</html>