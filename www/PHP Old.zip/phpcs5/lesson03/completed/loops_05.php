<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>foreach loop</title>
<link href="../../styles/examples.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>foreach Loop</h1>
<pre>
$book = array('title' =&gt; '&quot;Adobe Dreamweaver CS5 with PHP&quot;',
              'author' =&gt; 'David Powers');

foreach ($book as $item =&gt; $description) {
  echo &quot;&lt;p&gt;The book's $item is $description.&lt;/p&gt;&quot;;
}</pre>
<?php
$book = array('title' => '"Adobe Dreamweaver CS5 with PHP"',
              'author' => 'David Powers');
foreach ($book as $item => $description) {
	echo "<p>The book's $item is $description.</p>";
}
?>
</body>
</html>