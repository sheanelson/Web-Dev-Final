<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Adding strings</title>
<link href="../../styles/examples.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
window.onload = function() {
	var addition = '2' + '2';
	document.getElementById('result').innerHTML = addition;
}
</script>
</head>

<body>
<h1>Adding Strings</h1>
<p>'2' + '2' in Javascript: <span id="result"></span></p>
<p>'2' + '2' in PHP: <?php $addition = '2' + '2'; 
echo $addition; ?></p>
</body>
</html>