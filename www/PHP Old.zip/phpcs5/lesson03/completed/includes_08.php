<?php include('../test_includes/year_03.inc.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Testing PHP includes</title>
<link href="include_examples.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div id="wrapper">
  <?php include('header_02.html'); ?>
  <h1>Including HTML into a Page</h1>
  <p>Quis nostrud exercitation lorem ipsum dolor sit amet, excepteur sint occaecat. Ut enim ad minim veniam, duis aute irure dolor ullamco laboris nisi. Sunt in culpa consectetur adipisicing elit, ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, sed do eiusmod tempor incididunt cupidatat non proident.</p>
  <p>Quis nostrud exercitation ut labore et dolore magna aliqua. Excepteur sint occaecat ullamco laboris nisi eu fugiat nulla pariatur. Sed do eiusmod tempor incididunt ut aliquip ex ea commodo consequat. Ullamco laboris nisi sunt in culpa excepteur sint occaecat. Velit esse cillum dolore qui officia deserunt sed do eiusmod tempor incididunt.</p>
  <p>Ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, sunt in culpa ullamco laboris nisi. Eu fugiat nulla pariatur. Sed do eiusmod tempor incididunt ut enim ad minim veniam, duis aute irure dolor. Sunt in culpa.</p>
  <p>Ut aliquip ex ea commodo consequat. Velit esse cillum dolore quis nostrud exercitation in reprehenderit in voluptate. Ut enim ad minim veniam, sunt in culpa excepteur sint occaecat.</p>
  <p>Mollit anim id est laborum. Consectetur adipisicing elit, in reprehenderit in voluptate ullamco laboris nisi. Qui officia deserunt cupidatat non proident, quis nostrud exercitation. Velit esse cillum dolore sunt in culpa sed do eiusmod tempor incididunt.</p>
  <p>Ullamco laboris nisi velit esse cillum dolore consectetur adipisicing elit. Excepteur sint occaecat cupidatat non proident, sed do eiusmod tempor incididunt. Mollit anim id est laborum. Ut aliquip ex ea commodo consequat.</p>
  <p>Eu fugiat nulla pariatur. Quis nostrud exercitation excepteur sint occaecat lorem ipsum dolor sit amet. Ut labore et dolore magna aliqua. In reprehenderit in voluptate sed do eiusmod tempor incididunt quis nostrud exercitation.</p>
  <p>&copy; 2009<?php addYear(); ?> Birds of a Feather</p>
</div>
</body>
</html>