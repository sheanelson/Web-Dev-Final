<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Adding strings</title>
<link href="../../styles/examples.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Adding Strings</h1>
<p>$mayhem_or_harmony = '2 dogs' + '2 cats';</p>
<p>The result is:  <?php $mayhem_or_harmony = '2 dogs' + '2 cats'; 
echo $mayhem_or_harmony; ?></p>
<p>The data type of the result is: <?php 
// use the gettype() function to display the data type
echo gettype($mayhem_or_harmony); ?></p>
</body>
</html>