<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Joining strings</title>
<link href="../../styles/examples.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Joining Strings</h1>
<p>$first_name = 'David';</p>
<p>$family_name = 'Powers'</p>
<p>$full_name = $first_name . $family_name;</p>
<p>echo $full_name; 
<?php
$first_name = 'David';
$family_name = 'Powers';
$full_name = $first_name . $family_name;
echo $full_name;
?></p>
</body>
</html>