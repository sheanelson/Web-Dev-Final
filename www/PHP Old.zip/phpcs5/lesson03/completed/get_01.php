<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Submitting a form via GET</title>
<link href="../../styles/examples.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Sending Form Values by the GET Method</h1>
<form id="form1" name="form1" method="get" action="get_02.php">
  <p>
    <label for="first_name">First name:</label>
    <input type="text" name="first_name" id="first_name" />
  </p>
  <p>
    <label for="family_name">Family name:</label>
    <input type="text" name="family_name" id="family_name" />
  </p>
  <p>
    <input type="submit" name="send" id="send" value="Submit" />
  </p>
</form>
<p>&nbsp;</p>
</body>
</html>