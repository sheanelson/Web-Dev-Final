<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>foreach loop</title>
<link href="../../styles/examples.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>foreach Loop</h1>
<pre>$friends = array('Tom', 'Dick', 'Harriet');

foreach ($friends as $friend) {
  echo &quot;&lt;p&gt;$friend is a good friend.&lt;/p&gt;&quot;;
}</pre>
<p>
<?php
$friends = array('Tom', 'Dick', 'Harriet');
foreach ($friends as $friend) {
	echo "<p>$friend is a good friend.</p>";
}
?>
</p>
</body>
</html>