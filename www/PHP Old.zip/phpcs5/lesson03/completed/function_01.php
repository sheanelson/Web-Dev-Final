<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Using a function without capturing the result</title>
<link href="../../styles/examples.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Changing a Value Temporarily</h1>
<?php $name = 'David'; ?>
<p>$name is <?php echo $name; ?></p>
<p>echo strtoupper($name); displays <?php echo strtoupper($name); ?></p>
<p>$name is <?php echo $name; ?></p>
</body>
</html>