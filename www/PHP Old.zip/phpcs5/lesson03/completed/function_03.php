<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Using core functions</title>
<link href="../../styles/examples.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Using Core Functions</h1>
<?php $title = 'Adobe Dreamweaver CS5 with PHP'; ?>
<p>$title is: <?php echo $title; ?></p>
<?php $title = strrev($title); ?>
<p>After strrev(): <?php echo $title; ?></p>
<?php $title = strtoupper($title); ?>
<p>After strtoupper(): <?php echo $title; ?></p>
</body>
</html>