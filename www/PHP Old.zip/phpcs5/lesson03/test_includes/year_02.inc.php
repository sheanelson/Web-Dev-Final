<?php
if (date('Y') > 2009) {
  echo '&ndash;' . date('y');
}
?>
